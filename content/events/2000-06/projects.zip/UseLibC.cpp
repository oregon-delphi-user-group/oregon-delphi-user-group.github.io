//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("UseLibC.res");
USEFORM("UseLibCMain.cpp", frmUseLib);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->CreateForm(__classid(TfrmUseLib), &frmUseLib);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
