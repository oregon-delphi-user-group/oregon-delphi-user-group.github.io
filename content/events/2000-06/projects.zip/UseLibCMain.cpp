//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "UseLibCMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmUseLib *frmUseLib;

//---------------------------------------------------------------------------
__fastcall TfrmUseLib::TfrmUseLib(TComponent* Owner) : TForm(Owner)
{
}

//---------------------------------------------------------------------------
void __fastcall TfrmUseLib::cmbDrivesChange(TObject *Sender)
{
    lblFreeBytes->Caption = "testing ...";
    lblFreeMBytes->Caption = "testing2 ...";
}
//---------------------------------------------------------------------------
