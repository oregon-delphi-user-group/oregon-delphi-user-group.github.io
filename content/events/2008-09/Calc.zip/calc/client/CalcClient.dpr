program CalcClient;

uses
  Forms,
  ufrmCalcClient in 'ufrmCalcClient.pas' {Form4},
  uICalcService in 'uICalcService.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm4, Form4);
  Application.Run;
end.
