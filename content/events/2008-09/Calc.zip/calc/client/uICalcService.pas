// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://localhost:8081/CalcServer.Calc/wsdl/ICalcService
// Encoding : utf-8
// Version  : 1.0
// (9/15/2008 7:06:12 PM - * $Rev: 3108 $)
// ************************************************************************ //

unit uICalcService;

interface

uses InvokeRegistry, SOAPHTTPClient, Types, XSBuiltIns;

const
  AS_UNBOUNDED = false;

type

  // ************************************************************************ //
  // The following types, referred to in the WSDL document are not being represented
  // in this file. They are either aliases[@] of other types represented or were referred
  // to but never[!] declared in the document. The types from the latter category
  // typically map to predefined/known XML or Borland types; however, they could also 
  // indicate incorrect WSDL documents that failed to declare or import a schema type.
  // ************************************************************************ //
  // !:double          - "http://www.w3.org/2001/XMLSchema"


  // ************************************************************************ //
  // Namespace : urn:uCalcServiceIntf-ICalcService
  // soapAction: urn:uCalcServiceIntf-ICalcService#%operationName%
  // transport : http://schemas.xmlsoap.org/soap/http
  // style     : rpc
  // binding   : ICalcServicebinding
  // service   : ICalcServiceservice
  // port      : ICalcServicePort
  // URL       : http://localhost:8081/CalcServer.Calc/soap/ICalcService
  // ************************************************************************ //
  ICalcService = interface(IInvokable)
  ['{9D45554D-27CE-F3F1-2290-98B8D7294301}']
    function  Add(const a: Double; const b: Double): Double; stdcall;
    function  Subtract(const a: Double; const b: Double): Double; stdcall;
  end;

function GetICalcService(UseWSDL: Boolean=System.False; Addr: string=''; HTTPRIO: THTTPRIO = nil): ICalcService;


implementation
  uses SysUtils;

function GetICalcService(UseWSDL: Boolean; Addr: string; HTTPRIO: THTTPRIO): ICalcService;
const
  defWSDL = 'http://localhost:8081/CalcServer.Calc/wsdl/ICalcService';
  defURL  = 'http://localhost:8081/CalcServer.Calc/soap/ICalcService';
  defSvc  = 'ICalcServiceservice';
  defPrt  = 'ICalcServicePort';
var
  RIO: THTTPRIO;
begin
  Result := nil;
  if (Addr = '') then
  begin
    if UseWSDL then
      Addr := defWSDL
    else
      Addr := defURL;
  end;
  if HTTPRIO = nil then
    RIO := THTTPRIO.Create(nil)
  else
    RIO := HTTPRIO;
  try
    Result := (RIO as ICalcService);
    if UseWSDL then
    begin
      RIO.WSDLLocation := Addr;
      RIO.Service := defSvc;
      RIO.Port := defPrt;
    end else
      RIO.URL := Addr;
  finally
    if (Result = nil) and (HTTPRIO = nil) then
      RIO.Free;
  end;
end;


initialization
  InvRegistry.RegisterInterface(TypeInfo(ICalcService), 'urn:uCalcServiceIntf-ICalcService', 'utf-8');
  InvRegistry.RegisterDefaultSOAPAction(TypeInfo(ICalcService), 'urn:uCalcServiceIntf-ICalcService#%operationName%');

end.