object Form4: TForm4
  Left = 0
  Top = 0
  Caption = 'Simple Calc'
  ClientHeight = 151
  ClientWidth = 352
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -16
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 19
  object Label1: TLabel
    Left = 112
    Top = 48
    Width = 17
    Height = 19
    Caption = 'A:'
  end
  object Label2: TLabel
    Left = 112
    Top = 79
    Width = 15
    Height = 19
    Caption = 'B:'
  end
  object btnAdd: TButton
    Left = 216
    Top = 42
    Width = 89
    Height = 33
    Caption = '&Add'
    TabOrder = 0
    OnClick = btnAddClick
  end
  object btnSubtract: TButton
    Left = 207
    Top = 81
    Width = 89
    Height = 33
    Caption = '&Subtract'
    TabOrder = 3
    OnClick = btnSubtractClick
  end
  object edtNumA: TRzNumericEdit
    Left = 145
    Top = 45
    Width = 56
    Height = 27
    TabOrder = 1
    IntegersOnly = False
    DisplayFormat = '0.0'
  end
  object edtNumB: TRzNumericEdit
    Left = 145
    Top = 78
    Width = 56
    Height = 27
    TabOrder = 2
    IntegersOnly = False
    DisplayFormat = '0.0'
  end
end
