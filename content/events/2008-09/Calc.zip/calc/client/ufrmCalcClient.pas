unit ufrmCalcClient;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Mask, RzEdit;

type
  TForm4 = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    btnAdd: TButton;
    btnSubtract: TButton;
    edtNumA: TRzNumericEdit;
    edtNumB: TRzNumericEdit;
    procedure btnAddClick(Sender: TObject);
    procedure btnSubtractClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form4: TForm4;

implementation

{$R *.dfm}

uses
  uICalcService;

procedure TForm4.btnAddClick(Sender: TObject);
begin
  ShowMessage(Format('the answer is %f',
      [GetICalcService().Add(edtNumA.Value, edtNumb.Value)]));
end;

procedure TForm4.btnSubtractClick(Sender: TObject);
begin
  ShowMessage(Format('the answer is %f',
      [GetICalcService().Subtract(edtNumA.Value, edtNumb.Value)]));
end;

end.
