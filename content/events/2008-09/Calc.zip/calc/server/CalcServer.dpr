program CalcServer;

{$APPTYPE GUI}

uses
  Forms,
  SockApp,
  ufrmCalcServer in 'ufrmCalcServer.pas' {Form3},
  udmCalcServer in 'udmCalcServer.pas' {WebModule1: TWebModule},
  uCalcServiceImpl in 'uCalcServiceImpl.pas',
  uCalcServiceIntf in 'uCalcServiceIntf.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm3, Form3);
  Application.CreateForm(TWebModule1, WebModule1);
  Application.Run;
end.
