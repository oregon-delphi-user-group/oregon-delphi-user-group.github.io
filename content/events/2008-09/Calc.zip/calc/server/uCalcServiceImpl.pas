{ Invokable implementation File for TCalcService which implements ICalcService }

unit uCalcServiceImpl;

interface

uses InvokeRegistry, Types, XSBuiltIns, uCalcServiceIntf;

type

  { TCalcService }
  TCalcService = class(TInvokableClass, ICalcService)
  public
    function Add(const a, b: Double): Double; stdcall;
    function Subtract(const a, b: Double): Double; stdcall;
  end;

implementation


{ TCalcService }

function TCalcService.Add(const a, b: Double): Double;
begin
  Result := a + b;
end;

function TCalcService.Subtract(const a, b: Double): Double;
begin
  Result := a - b;
end;

initialization
{ Invokable classes must be registered }
   InvRegistry.RegisterInvokableClass(TCalcService);
end.

