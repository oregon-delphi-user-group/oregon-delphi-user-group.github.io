{ Invokable interface ICalcService }

unit uCalcServiceIntf;

interface

uses InvokeRegistry, Types, XSBuiltIns;

type

  { Invokable interfaces must derive from IInvokable }
  ICalcService = interface(IInvokable)
  ['{91843886-9D64-449B-A332-75318D2F208E}']
    function Add(const a, b: Double): Double; stdcall;
    function Subtract(const a, b: Double): Double; stdcall;
    { Methods of Invokable interface must not use the default }
    { calling convention; stdcall is recommended }
  end;

implementation

initialization
  { Invokable interfaces must be registered }
  InvRegistry.RegisterInterface(TypeInfo(ICalcService));

end.
