program DBSampleClient;

uses
  Forms,
  ufrmDBSampleClient in 'ufrmDBSampleClient.pas' {frmDBSample},
  uICustomers in 'uICustomers.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TfrmDBSample, frmDBSample);
  Application.Run;
end.
