// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://localhost:8081/DBSampleServer.DatabaseExample/wsdl/ICustomers
//  >Import : http://localhost:8081/DBSampleServer.DatabaseExample/wsdl/ICustomers:0
// Encoding : utf-8
// Version  : 1.0
// (9/14/2008 1:25:48 PM - * $Rev: 3108 $)
// ************************************************************************ //

unit uICustomers;

interface

uses InvokeRegistry, SOAPHTTPClient, Types, XSBuiltIns;

const
  AS_UNBOUNDED = false;

type

  // ************************************************************************ //
  // The following types, referred to in the WSDL document are not being represented
  // in this file. They are either aliases[@] of other types represented or were referred
  // to but never[!] declared in the document. The types from the latter category
  // typically map to predefined/known XML or Borland types; however, they could also 
  // indicate incorrect WSDL documents that failed to declare or import a schema type.
  // ************************************************************************ //
  // !:int             - "http://www.w3.org/2001/XMLSchema"
  // !:string          - "http://www.w3.org/2001/XMLSchema"
  // !:boolean         - "http://www.w3.org/2001/XMLSchema"

  ContactDetails       = class;                 { "urn:uCustomersIntf"[GblCplx] }

  ArrayOfContactIDs = array of Integer;         { "urn:uCustomersIntf"[GblCplx] }


  // ************************************************************************ //
  // XML       : ContactDetails, global, <complexType>
  // Namespace : urn:uCustomersIntf
  // ************************************************************************ //
  ContactDetails = class(TRemotable)
  private
    FID: Integer;
    FContactCode: WideString;
    FCompany: WideString;
    FAddress1: WideString;
    FAddress2: WideString;
    FAddress3: WideString;
    FAddress4: WideString;
    FAddress5: WideString;
    FPhone1: WideString;
    FPhone2: WideString;
    FMobile: WideString;
    FFax: WideString;
    FEmail: WideString;
  published
    property ID: Integer read FID write FID;
    property ContactCode: WideString read FContactCode write FContactCode;
    property Company: WideString read FCompany write FCompany;
    property Address1: WideString read FAddress1 write FAddress1;
    property Address2: WideString read FAddress2 write FAddress2;
    property Address3: WideString read FAddress3 write FAddress3;
    property Address4: WideString read FAddress4 write FAddress4;
    property Address5: WideString read FAddress5 write FAddress5;
    property Phone1: WideString read FPhone1 write FPhone1;
    property Phone2: WideString read FPhone2 write FPhone2;
    property Mobile: WideString read FMobile write FMobile;
    property Fax: WideString read FFax write FFax;
    property Email: WideString read FEmail write FEmail;
  end;


  // ************************************************************************ //
  // Namespace : urn:uCustomersIntf-ICustomers
  // soapAction: urn:uCustomersIntf-ICustomers#%operationName%
  // transport : http://schemas.xmlsoap.org/soap/http
  // style     : rpc
  // binding   : ICustomersbinding
  // service   : ICustomersservice
  // port      : ICustomersPort
  // URL       : http://localhost:8081/DBSampleServer.DatabaseExample/soap/ICustomers
  // ************************************************************************ //
  ICustomers = interface(IInvokable)
  ['{1E6F27CD-5CB3-5654-365D-F17E376CE156}']
    function  GetCustomerIDs(const GetActive: Boolean): ArrayOfContactIDs; stdcall;
    function  GetVendorIDs(const GetActive: Boolean): ArrayOfContactIDs; stdcall;
    function  GetContact(const ID: Integer): ContactDetails; stdcall;
  end;

function GetICustomers(UseWSDL: Boolean=System.False; Addr: string=''; HTTPRIO: THTTPRIO = nil): ICustomers;


implementation
  uses SysUtils;

function GetICustomers(UseWSDL: Boolean; Addr: string; HTTPRIO: THTTPRIO): ICustomers;
const
  defWSDL = 'http://localhost:8081/DBSampleServer.DatabaseExample/wsdl/ICustomers';
  defURL  = 'http://localhost:8081/DBSampleServer.DatabaseExample/soap/ICustomers';
  defSvc  = 'ICustomersservice';
  defPrt  = 'ICustomersPort';
var
  RIO: THTTPRIO;
begin
  Result := nil;
  if (Addr = '') then
  begin
    if UseWSDL then
      Addr := defWSDL
    else
      Addr := defURL;
  end;
  if HTTPRIO = nil then
    RIO := THTTPRIO.Create(nil)
  else
    RIO := HTTPRIO;
  try
    Result := (RIO as ICustomers);
    if UseWSDL then
    begin
      RIO.WSDLLocation := Addr;
      RIO.Service := defSvc;
      RIO.Port := defPrt;
    end else
      RIO.URL := Addr;
  finally
    if (Result = nil) and (HTTPRIO = nil) then
      RIO.Free;
  end;
end;


initialization
  InvRegistry.RegisterInterface(TypeInfo(ICustomers), 'urn:uCustomersIntf-ICustomers', 'utf-8');
  InvRegistry.RegisterDefaultSOAPAction(TypeInfo(ICustomers), 'urn:uCustomersIntf-ICustomers#%operationName%');
  RemClassRegistry.RegisterXSInfo(TypeInfo(ArrayOfContactIDs), 'urn:uCustomersIntf', 'ArrayOfContactIDs');
  RemClassRegistry.RegisterXSClass(ContactDetails, 'urn:uCustomersIntf', 'ContactDetails');

end.