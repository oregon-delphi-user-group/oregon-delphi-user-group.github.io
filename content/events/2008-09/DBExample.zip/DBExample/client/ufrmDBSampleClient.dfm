object frmDBSample: TfrmDBSample
  Left = 0
  Top = 0
  Caption = 'DB Sample'
  ClientHeight = 266
  ClientWidth = 529
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  DesignSize = (
    529
    266)
  PixelsPerInch = 96
  TextHeight = 13
  object lblID: TLabel
    Left = 264
    Top = 16
    Width = 21
    Height = 13
    Caption = 'lblID'
  end
  object lblContactCode: TLabel
    Left = 368
    Top = 16
    Width = 73
    Height = 13
    Caption = 'lblContactCode'
  end
  object lblCompany: TLabel
    Left = 264
    Top = 40
    Width = 55
    Height = 13
    Caption = 'lblCompany'
  end
  object lblAddress1: TLabel
    Left = 264
    Top = 64
    Width = 55
    Height = 13
    Caption = 'lblAddress1'
  end
  object lblAddress2: TLabel
    Left = 264
    Top = 83
    Width = 55
    Height = 13
    Caption = 'lblAddress2'
  end
  object lblAddress3: TLabel
    Left = 264
    Top = 102
    Width = 55
    Height = 13
    Caption = 'lblAddress3'
  end
  object lblAddress4: TLabel
    Left = 264
    Top = 121
    Width = 55
    Height = 13
    Caption = 'lblAddress4'
  end
  object lblAddress5: TLabel
    Left = 264
    Top = 140
    Width = 55
    Height = 13
    Caption = 'lblAddress5'
  end
  object lblPhone1: TLabel
    Left = 264
    Top = 160
    Width = 46
    Height = 13
    Caption = 'lblPhone1'
  end
  object lblPhone2: TLabel
    Left = 264
    Top = 179
    Width = 46
    Height = 13
    Caption = 'lblPhone2'
  end
  object lblMobile: TLabel
    Left = 264
    Top = 198
    Width = 40
    Height = 13
    Caption = 'lblMobile'
  end
  object lblFax: TLabel
    Left = 264
    Top = 217
    Width = 28
    Height = 13
    Caption = 'lblFax'
  end
  object lblEmail: TLabel
    Left = 264
    Top = 240
    Width = 34
    Height = 13
    Caption = 'lblEmail'
  end
  object btnGetCustIDs: TButton
    Left = 32
    Top = 24
    Width = 75
    Height = 25
    Caption = '&Customer IDs'
    TabOrder = 0
    OnClick = btnGetCustIDsClick
  end
  object btnGetVendIDs: TButton
    Left = 32
    Top = 55
    Width = 75
    Height = 25
    Caption = '&Vendor IDs'
    TabOrder = 1
    OnClick = btnGetVendIDsClick
  end
  object lbIDs: TListBox
    Left = 137
    Top = 8
    Width = 105
    Height = 250
    Anchors = [akLeft, akTop, akBottom]
    ItemHeight = 13
    TabOrder = 2
    OnClick = lbIDsClick
  end
  object cbActive: TCheckBox
    Left = 42
    Top = 96
    Width = 65
    Height = 17
    Caption = '&Active'
    Checked = True
    State = cbChecked
    TabOrder = 3
  end
end
