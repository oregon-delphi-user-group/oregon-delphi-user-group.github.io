unit ufrmDBSampleClient;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls,
  uICustomers;

type
  TfrmDBSample = class(TForm)
    btnGetCustIDs: TButton;
    btnGetVendIDs: TButton;
    lbIDs: TListBox;
    cbActive: TCheckBox;
    lblID: TLabel;
    lblContactCode: TLabel;
    lblCompany: TLabel;
    lblAddress1: TLabel;
    lblAddress2: TLabel;
    lblAddress3: TLabel;
    lblAddress4: TLabel;
    lblAddress5: TLabel;
    lblPhone1: TLabel;
    lblPhone2: TLabel;
    lblMobile: TLabel;
    lblFax: TLabel;
    lblEmail: TLabel;
    procedure btnGetCustIDsClick(Sender: TObject);
    procedure btnGetVendIDsClick(Sender: TObject);
    procedure lbIDsClick(Sender: TObject);
  private
    procedure ShowContact(ContactID: Integer);
  end;

var
  frmDBSample: TfrmDBSample;

implementation

{$R *.dfm}

procedure TfrmDBSample.btnGetCustIDsClick(Sender: TObject);
var
  cust_list: ArrayOfContactIDs;
  i: Integer;
begin
  lbIDs.Items.Clear;

  cust_list := GetICustomers().GetCustomerIDs(cbActive.Checked);
  for i := 0 to Length(cust_list) - 1 do
    lbIDs.Items.Add(IntToStr(cust_list[i]));

  ShowMessage(Format('Found %d customers', [Length(cust_list)]));
end;

procedure TfrmDBSample.btnGetVendIDsClick(Sender: TObject);
var
  vend_list: ArrayOfContactIDs;
  i: Integer;
begin
  lbIDs.Items.Clear;

  vend_list := GetICustomers().GetVendorIDs(cbActive.Checked);
  for i := 0 to Length(vend_list) - 1 do
    lbIDs.Items.Add(IntToStr(vend_list[i]));

  ShowMessage(Format('Found %d vendors', [Length(vend_list)]));
end;

procedure TfrmDBSample.lbIDsClick(Sender: TObject);
begin
  if lbIDs.Count > 0 then
    ShowContact(StrToInt(lbIDs.Items[lbIDs.ItemIndex]));
end;

procedure TfrmDBSample.ShowContact(ContactID: Integer);
var
  contact: ContactDetails;
begin
  contact := GetICustomers().GetContact(ContactID);
  with Contact do begin
    lblID.Caption          := 'ID = ' + IntToStr(ID);
    lblContactCode.Caption := 'Code = ' + ContactCode;
    lblCompany.Caption     := 'Company = ' + Company;
    lblAddress1.Caption    := 'Addr1 = ' + Address1;
    lblAddress2.Caption    := 'Addr2 = ' + Address2;
    lblAddress3.Caption    := 'Addr3 = ' + Address3;
    lblAddress4.Caption    := 'Addr4 = ' + Address4;
    lblAddress5.Caption    := 'Addr5 = ' + Address5;
    lblPhone1.Caption      := 'Phone1 = ' + Phone1;
    lblPhone2.Caption      := 'Phone2 = ' + Phone2;
    lblMobile.Caption      := 'Mobile = ' + Mobile;
    lblFax.Caption         := 'Fax = ' + Fax;
    lblEmail.Caption       := 'Email = ' + Email;
  end;
end;

end.
