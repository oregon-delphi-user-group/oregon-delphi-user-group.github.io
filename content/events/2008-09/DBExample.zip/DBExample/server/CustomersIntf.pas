{ Invokable interface ICustomers }

unit CustomersIntf;

interface

uses InvokeRegistry, Types, XSBuiltIns;

type

  { Invokable interfaces must derive from IInvokable }
  ICustomers = interface(IInvokable)
  ['{6A54F3E3-2A13-4C43-B006-7992DD3348C1}']

    { Methods of Invokable interface must not use the default }
    { calling convention; stdcall is recommended }
  end;

implementation

initialization
  { Invokable interfaces must be registered }
  InvRegistry.RegisterInterface(TypeInfo(ICustomers));

end.
