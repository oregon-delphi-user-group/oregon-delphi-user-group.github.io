program DBSampleServer;

{$APPTYPE GUI}

uses
  Forms,
  SockApp,
  ufrmDBSampleServer in 'ufrmDBSampleServer.pas' {frmDBSampleServer},
  udmDBSampleServer in 'udmDBSampleServer.pas' {WebModule3: TWebModule},
  uCustomersImpl in 'uCustomersImpl.pas',
  uCustomersIntf in 'uCustomersIntf.pas',
  udmDBContacts in 'udmDBContacts.pas' {dmDBContacts: TDataModule};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TfrmDBSampleServer, frmDBSampleServer);
  Application.CreateForm(TWebModule3, WebModule3);
  Application.CreateForm(TdmDBContacts, dmDBContacts);
  Application.Run;
end.
