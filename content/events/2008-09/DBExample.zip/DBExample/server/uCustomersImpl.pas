{ Invokable implementation File for TCustomers which implements ICustomers }

unit uCustomersImpl;

interface

uses InvokeRegistry, Types, XSBuiltIns, uCustomersIntf;

type

  { TCustomers }
  TCustomers = class(TInvokableClass, ICustomers)
  public
    function GetCustomerIDs(const GetActive: Boolean = True): ArrayOfContactIDs; stdcall;
    function GetVendorIDs(const GetActive: Boolean = True): ArrayOfContactIDs; stdcall;
    function GetContact(const ID: Integer): ContactDetails; stdcall;
  end;

implementation

uses
  CodeSiteLogging,
  udmDBContacts;

{ TCustomers }

function TCustomers.GetContact(const ID: Integer): ContactDetails;
var
  AContact: ContactDetails;
begin
  CodeSite.EnterMethod( Self, 'GetContact' );
  dmDBContacts.qryGetContact.ParamByName('ID').AsInteger := ID;
  dmDBContacts.qryGetContact.Open;

  AContact := ContactDetails.Create;
  with AContact do begin
    ID          := dmDBContacts.qryGetContactID.AsInteger;
    ContactCode := dmDBContacts.qryGetContactContactCode.AsString;
    Company     := dmDBContacts.qryGetContactCompany.AsString;
    Address1    := dmDBContacts.qryGetContactAddress1.AsString;
    Address2    := dmDBContacts.qryGetContactAddress2.AsString;
    Address3    := dmDBContacts.qryGetContactAddress3.AsString;
    Address4    := dmDBContacts.qryGetContactAddress4.AsString;
    Address5    := dmDBContacts.qryGetContactAddress5.AsString;
    Phone1      := dmDBContacts.qryGetContactPhone1.AsString;
    Phone2      := dmDBContacts.qryGetContactPhone2.AsString;
    Mobile      := dmDBContacts.qryGetContactMobile.AsString;
    Fax         := dmDBContacts.qryGetContactFax.AsString;
    Email       := dmDBContacts.qryGetContactEmail.AsString;
  end;

  dmDBContacts.qryGetContact.close;

  Result := AContact;

  CodeSite.ExitMethod( Self, 'GetContact' );
end;

function TCustomers.GetCustomerIDs(const GetActive: Boolean = True): ArrayOfContactIDs;
var
  id: Integer;
begin
  CodeSite.EnterMethod( Self, 'GetCustomerIDs' );
  SetLength(Result, 0);
  id := dmDBContacts.GetFirstCustomer(GetActive);
  while id > 0 do begin
    SetLength(Result, Length(Result) + 1);
    Result[Length(Result) - 1] := id;
    id := dmDBContacts.GetNextCustomer;
  end;
  CodeSite.ExitMethod( Self, 'GetCustomerIDs' );
end;

function TCustomers.GetVendorIDs(const GetActive: Boolean = True): ArrayOfContactIDs;
var
  id: Integer;
begin
  CodeSite.EnterMethod( Self, 'GetVendorIDs' );
  SetLength(Result, 0);
  id := dmDBContacts.GetFirstVendor(GetActive);
  while id > 0 do begin
    SetLength(Result, Length(Result) + 1);
    Result[Length(Result) - 1] := id;
    id := dmDBContacts.GetNextVendor;
  end;
  CodeSite.ExitMethod( Self, 'GetVendorIDs' );
end;

initialization
{ Invokable classes must be registered }
   InvRegistry.RegisterInvokableClass(TCustomers);
end.


