{ Invokable interface ICustomers }

unit uCustomersIntf;

interface

uses InvokeRegistry, Types, XSBuiltIns;

type
  ArrayOfContactIDs = array of Integer;

  ContactDetails = class(TRemotable)
  private
    FContactCode: string;
    FEmail: string;
    FFax: string;
    FMobile: string;
    FPhone2: string;
    FPhone1: string;
    FCompany: string;
    FID: Integer;
    FAddress2: string;
    FAddress3: string;
    FAddress1: string;
    FAddress4: string;
    FAddress5: string;
  published
    property ID: Integer read FID write FID;
    property ContactCode: string read FContactCode write FContactCode;
    property Company: string read FCompany write FCompany;
    property Address1: string read FAddress1 write FAddress1;
    property Address2: string read FAddress2 write FAddress2;
    property Address3: string read FAddress3 write FAddress3;
    property Address4: string read FAddress4 write FAddress4;
    property Address5: string read FAddress5 write FAddress5;
    property Phone1: string read FPhone1 write FPhone1;
    property Phone2: string read FPhone2 write FPhone2;
    property Mobile: string read FMobile write FMobile;
    property Fax: string read FFax write FFax;
    property Email: string read FEmail write FEmail;
  end;

  { Invokable interfaces must derive from IInvokable }
  ICustomers = interface(IInvokable)
  ['{6A54F3E3-2A13-4C43-B006-7992DD3348C1}']
    function GetCustomerIDs(const GetActive: Boolean = True): ArrayOfContactIDs; stdcall;
    function GetVendorIDs(const GetActive: Boolean = True): ArrayOfContactIDs; stdcall;
    function GetContact(const ID: Integer): ContactDetails; stdcall;
    { Methods of Invokable interface must not use the default }
    { calling convention; stdcall is recommended }
  end;

implementation

initialization
  { Invokable interfaces must be registered }
  InvRegistry.RegisterInterface(TypeInfo(ICustomers));

end.
