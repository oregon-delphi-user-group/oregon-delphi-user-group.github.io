object dmDBContacts: TdmDBContacts
  OldCreateOrder = False
  Height = 200
  Width = 277
  object EDBEngine: TEDBEngine
    Active = True
    Signature = 'edb_signature'
    EncryptionPassword = 'elevatesoft'
    LicensedSessions = 4096
    ConfigPath = 'C:\Documents and Settings\All Users\Application Data\DCI Imports'
    ConfigName = 'EDBConfig'
    ConfigExtension = '.EDBCfg'
    LockExtension = '.EDBLck'
    LogExtension = '.EDBLog'
    MaxLogFileSize = 1048576
    LogCategories = [lcInformation, lcWarning, lcError]
    CatalogName = 'EDBDatabase'
    CatalogExtension = '.EDBCat'
    BackupExtension = '.EDBBkp'
    UpdateExtension = '.EDBUpd'
    TableExtension = '.EDBTbl'
    TableIndexExtension = '.EDBIdx'
    TableBlobExtension = '.EDBBlb'
    TablePublishExtension = '.EDBPbl'
    TempTablesPath = 'C:\DOCUME~1\ADMINI~1\LOCALS~1\Temp\'
    ServerName = 'EDBSrvr'
    ServerDescription = 'ElevateDB Server'
    ServerAuthorizedAddresses.Strings = (
      '*')
    Left = 40
    Top = 24
  end
  object EDBSession: TEDBSession
    Connected = True
    LoginUser = 'Administrator'
    LoginPassword = 'EDBDefault'
    SessionName = 'WebServiceSample'
    LocalSignature = 'edb_signature'
    LocalEncryptionPassword = 'elevatesoft'
    LocalConfigPath = 'C:\Documents and Settings\All Users\Application Data\DCI Imports'
    LocalConfigName = 'EDBConfig'
    LocalConfigExtension = '.EDBCfg'
    LocalLockExtension = '.EDBLck'
    LocalLogExtension = '.EDBLog'
    LocalMaxLogFileSize = 1048576
    LocalLogCategories = [lcInformation, lcWarning, lcError]
    LocalCatalogName = 'EDBDatabase'
    LocalCatalogExtension = '.EDBCat'
    LocalBackupExtension = '.EDBBkp'
    LocalUpdateExtension = '.EDBUpd'
    LocalTableExtension = '.EDBTbl'
    LocalTableIndexExtension = '.EDBIdx'
    LocalTableBlobExtension = '.EDBBlb'
    LocalTablePublishExtension = '.EDBPbl'
    LocalTempTablesPath = 'C:\DOCUME~1\ADMINI~1\LOCALS~1\Temp\'
    RemoteSignature = 'edb_signature'
    RemoteEncryptionPassword = 'elevatesoft'
    RemoteAddress = '127.0.0.1'
    Left = 40
    Top = 72
  end
  object EDBDatabase: TEDBDatabase
    Connected = True
    DatabaseName = 'dci'
    Database = 'DCI'
    SessionName = 'WebServiceSample'
    Left = 40
    Top = 128
  end
  object qryCustList: TEDBQuery
    DatabaseName = 'dci'
    SessionName = 'WebServiceSample'
    SQL.Strings = (
      'SELECT ID FROM Contacts'
      'WHERE ContactCode LIKE '#39'C%'#39
      '  AND Active = :Active')
    Params = <
      item
        DataType = ftBoolean
        Name = 'Active'
        ParamType = ptInput
      end>
    ReadOnly = True
    Left = 112
    Top = 40
    object qryCustListID: TIntegerField
      FieldName = 'ID'
    end
  end
  object qryVendList: TEDBQuery
    DatabaseName = 'dci'
    SessionName = 'WebServiceSample'
    SQL.Strings = (
      'SELECT ID FROM Contacts'
      'WHERE ContactCode LIKE '#39'V%'#39
      '  AND Active = :Active')
    Params = <
      item
        DataType = ftBoolean
        Name = 'Active'
        ParamType = ptInput
      end>
    ReadOnly = True
    Left = 112
    Top = 96
    object qryVendListID: TIntegerField
      FieldName = 'ID'
      Origin = 'Contacts.ID'
    end
  end
  object qryGetContact: TEDBQuery
    DatabaseName = 'dci'
    SessionName = 'WebServiceSample'
    SQL.Strings = (
      'SELECT ID, ContactCode, Company,'
      '  Address1, Address2, Address3, Address4, Address5,'
      '  Phone1, Phone2, Mobile, Fax, Email, CreditApproved,'
      '  ChristmasList, Active, SalesStaffID'
      'FROM Contacts'
      '  WHERE ID = :ID')
    Params = <
      item
        DataType = ftInteger
        Name = 'ID'
        ParamType = ptInput
      end>
    ReadOnly = True
    Left = 184
    Top = 48
    object qryGetContactID: TIntegerField
      FieldName = 'ID'
    end
    object qryGetContactContactCode: TStringField
      FieldName = 'ContactCode'
      Size = 4
    end
    object qryGetContactCompany: TStringField
      FieldName = 'Company'
      Size = 30
    end
    object qryGetContactAddress1: TStringField
      FieldName = 'Address1'
      Size = 30
    end
    object qryGetContactAddress2: TStringField
      FieldName = 'Address2'
      Size = 30
    end
    object qryGetContactAddress3: TStringField
      FieldName = 'Address3'
      Size = 30
    end
    object qryGetContactAddress4: TStringField
      FieldName = 'Address4'
      Size = 30
    end
    object qryGetContactAddress5: TStringField
      FieldName = 'Address5'
      Size = 30
    end
    object qryGetContactPhone1: TStringField
      FieldName = 'Phone1'
      Size = 15
    end
    object qryGetContactPhone2: TStringField
      FieldName = 'Phone2'
      Size = 15
    end
    object qryGetContactMobile: TStringField
      FieldName = 'Mobile'
      Size = 15
    end
    object qryGetContactFax: TStringField
      FieldName = 'Fax'
      Size = 15
    end
    object qryGetContactEmail: TStringField
      FieldName = 'Email'
      Size = 200
    end
    object qryGetContactCreditApproved: TBCDField
      FieldName = 'CreditApproved'
      Size = 2
    end
    object qryGetContactChristmasList: TBooleanField
      FieldName = 'ChristmasList'
    end
    object qryGetContactActive: TBooleanField
      FieldName = 'Active'
    end
    object qryGetContactSalesStaffID: TIntegerField
      FieldName = 'SalesStaffID'
    end
  end
end
