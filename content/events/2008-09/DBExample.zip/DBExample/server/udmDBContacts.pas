unit udmDBContacts;

interface

uses
  SysUtils, Classes, DB, edbcomps;

type
  TdmDBContacts = class(TDataModule)
    EDBEngine: TEDBEngine;
    EDBSession: TEDBSession;
    EDBDatabase: TEDBDatabase;
    qryCustList: TEDBQuery;
    qryVendList: TEDBQuery;
    qryVendListID: TIntegerField;
    qryCustListID: TIntegerField;
    qryGetContact: TEDBQuery;
    qryGetContactID: TIntegerField;
    qryGetContactContactCode: TStringField;
    qryGetContactCompany: TStringField;
    qryGetContactAddress1: TStringField;
    qryGetContactAddress2: TStringField;
    qryGetContactAddress3: TStringField;
    qryGetContactAddress4: TStringField;
    qryGetContactAddress5: TStringField;
    qryGetContactPhone1: TStringField;
    qryGetContactPhone2: TStringField;
    qryGetContactMobile: TStringField;
    qryGetContactFax: TStringField;
    qryGetContactEmail: TStringField;
    qryGetContactCreditApproved: TBCDField;
    qryGetContactChristmasList: TBooleanField;
    qryGetContactActive: TBooleanField;
    qryGetContactSalesStaffID: TIntegerField;
  public
    function GetFirstCustomer(const GetActive: Boolean): Integer;
    function GetNextCustomer: Integer;
    function GetFirstVendor(const GetActive: Boolean): Integer;
    function GetNextVendor: Integer;
  end;

var
  dmDBContacts: TdmDBContacts;

implementation

{$R *.dfm}

uses
  CodeSiteLogging;

{ TdmDBContacts }

function TdmDBContacts.GetFirstCustomer(const GetActive: Boolean): Integer;
begin
  CodeSite.EnterMethod( Self, 'GetFirstCustomer' );

  qryCustList.ParamByName('Active').AsBoolean := GetActive;
  qryCustList.Open;

  qryCustList.First;
  Result := qryCustListID.AsInteger;

  CodeSite.Send('Result', Result);
  CodeSite.ExitMethod( Self, 'GetFirstCustomer' );
end;

function TdmDBContacts.GetFirstVendor(const GetActive: Boolean): Integer;
begin
  CodeSite.EnterMethod( Self, 'GetFirstVendor' );

  qryVendList.ParamByName('Active').AsBoolean := GetActive;
  qryVendList.Open;

  qryVendList.First;
  Result := qryVendListID.AsInteger;

  CodeSite.Send('Result', Result);
  CodeSite.ExitMethod( Self, 'GetFirstVendor' );
end;

function TdmDBContacts.GetNextCustomer: Integer;
begin
  CodeSite.EnterMethod( Self, 'GetNextCustomer' );
  try
    qryCustList.Next;
    if qryCustList.EOF then begin
      qryCustList.Close;
      Result := -1;
    end else
      Result := qryCustListID.AsInteger;
  except
    Result := -1;
  end;
  CodeSite.Send('Result', Result);
  CodeSite.ExitMethod( Self, 'GetNextCustomer' );
end;

function TdmDBContacts.GetNextVendor: Integer;
begin
  CodeSite.EnterMethod( Self, 'GetNextVendor' );
  try
    qryVendList.next;
    if qryVendList.EOF then begin
      qryVendList.Close;
      Result := -1;
    end else
      Result := qryVendListID.AsInteger;
  except
    Result := -1;
  end;
  CodeSite.Send('Result', Result); 
  CodeSite.ExitMethod( Self, 'GetNextVendor' );
end;

end.

