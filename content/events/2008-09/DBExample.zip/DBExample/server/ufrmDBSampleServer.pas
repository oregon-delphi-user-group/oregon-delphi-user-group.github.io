unit ufrmDBSampleServer;

interface

uses
  SysUtils, Classes, Forms;

type
  TfrmDBSampleServer = class(TForm)
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmDBSampleServer: TfrmDBSampleServer;

implementation

uses SockApp;

{$R *.dfm}

initialization
  TWebAppSockObjectFactory.Create('DatabaseExample')

end.
