program HelloWorldClient;

uses
  Forms,
  ufrmHelloWorldClient in 'ufrmHelloWorldClient.pas' {Form2},
  uIHelloWorldService in 'uIHelloWorldService.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm2, Form2);
  Application.Run;
end.
