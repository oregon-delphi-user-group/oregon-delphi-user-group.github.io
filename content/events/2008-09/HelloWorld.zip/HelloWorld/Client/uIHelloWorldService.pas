// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://localhost:8081/HelloWorldWebService.HelloWorld/wsdl/IHelloWorldService
// Encoding : utf-8
// Version  : 1.0
// (9/15/2008 6:41:53 PM - * $Rev: 3108 $)
// ************************************************************************ //

unit uIHelloWorldService;

interface

uses InvokeRegistry, SOAPHTTPClient, Types, XSBuiltIns;

const
  AS_UNBOUNDED = false;

type

  // ************************************************************************ //
  // The following types, referred to in the WSDL document are not being represented
  // in this file. They are either aliases[@] of other types represented or were referred
  // to but never[!] declared in the document. The types from the latter category
  // typically map to predefined/known XML or Borland types; however, they could also 
  // indicate incorrect WSDL documents that failed to declare or import a schema type.
  // ************************************************************************ //
  // !:string          - "http://www.w3.org/2001/XMLSchema"


  // ************************************************************************ //
  // Namespace : urn:HelloWorldServiceIntf-IHelloWorldService
  // soapAction: urn:HelloWorldServiceIntf-IHelloWorldService#SayHello
  // transport : http://schemas.xmlsoap.org/soap/http
  // style     : rpc
  // binding   : IHelloWorldServicebinding
  // service   : IHelloWorldServiceservice
  // port      : IHelloWorldServicePort
  // URL       : http://localhost:8081/HelloWorldWebService.HelloWorld/soap/IHelloWorldService
  // ************************************************************************ //
  IHelloWorldService = interface(IInvokable)
  ['{4C241709-5F8F-A2F8-F8D4-763EAF9B184B}']
    function  SayHello: WideString; stdcall;
  end;

function GetIHelloWorldService(UseWSDL: Boolean=System.False; Addr: string=''; HTTPRIO: THTTPRIO = nil): IHelloWorldService;


implementation
  uses SysUtils;

function GetIHelloWorldService(UseWSDL: Boolean; Addr: string; HTTPRIO: THTTPRIO): IHelloWorldService;
const
  defWSDL = 'http://localhost:8081/HelloWorldWebService.HelloWorld/wsdl/IHelloWorldService';
  defURL  = 'http://localhost:8081/HelloWorldWebService.HelloWorld/soap/IHelloWorldService';
  defSvc  = 'IHelloWorldServiceservice';
  defPrt  = 'IHelloWorldServicePort';
var
  RIO: THTTPRIO;
begin
  Result := nil;
  if (Addr = '') then
  begin
    if UseWSDL then
      Addr := defWSDL
    else
      Addr := defURL;
  end;
  if HTTPRIO = nil then
    RIO := THTTPRIO.Create(nil)
  else
    RIO := HTTPRIO;
  try
    Result := (RIO as IHelloWorldService);
    if UseWSDL then
    begin
      RIO.WSDLLocation := Addr;
      RIO.Service := defSvc;
      RIO.Port := defPrt;
    end else
      RIO.URL := Addr;
  finally
    if (Result = nil) and (HTTPRIO = nil) then
      RIO.Free;
  end;
end;


initialization
  InvRegistry.RegisterInterface(TypeInfo(IHelloWorldService), 'urn:HelloWorldServiceIntf-IHelloWorldService', 'utf-8');
  InvRegistry.RegisterDefaultSOAPAction(TypeInfo(IHelloWorldService), 'urn:HelloWorldServiceIntf-IHelloWorldService#SayHello');

end.