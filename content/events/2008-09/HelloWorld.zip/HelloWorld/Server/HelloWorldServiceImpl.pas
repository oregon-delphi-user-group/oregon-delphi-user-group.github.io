{ Invokable implementation File for THelloWorldService which implements IHelloWorldService }

unit HelloWorldServiceImpl;

interface

uses InvokeRegistry, Types, XSBuiltIns, HelloWorldServiceIntf;

type

  { THelloWorldService }
  THelloWorldService = class(TInvokableClass, IHelloWorldService)
  public
    function SayHello: string; stdcall;
  end;

implementation


{ THelloWorldService }

function THelloWorldService.SayHello: string;
begin
  Result := 'Hello Web Service World!';
end;

initialization
{ Invokable classes must be registered }
   InvRegistry.RegisterInvokableClass(THelloWorldService);
end.

