{ Invokable interface IHelloWorldService }

unit HelloWorldServiceIntf;

interface

uses InvokeRegistry, Types, XSBuiltIns;

type

  { Invokable interfaces must derive from IInvokable }
  IHelloWorldService = interface(IInvokable)
  ['{7BBD76E1-2C1F-4D16-A1AB-BEE5DDC83FD8}']
    function SayHello: string; stdcall;
    { Methods of Invokable interface must not use the default }
    { calling convention; stdcall is recommended }
  end;

implementation

initialization
  { Invokable interfaces must be registered }
  InvRegistry.RegisterInterface(TypeInfo(IHelloWorldService));

end.
