program HelloWorldWebService;

{$APPTYPE GUI}

uses
  Forms,
  SockApp,
  ufrmHelloWorld in 'ufrmHelloWorld.pas' {Form1},
  dmHelloWorld in 'dmHelloWorld.pas' {WebModule2: TWebModule},
  HelloWorldServiceImpl in 'HelloWorldServiceImpl.pas',
  HelloWorldServiceIntf in 'HelloWorldServiceIntf.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TWebModule2, WebModule2);
  Application.Run;
end.
