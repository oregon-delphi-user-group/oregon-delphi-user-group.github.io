program DelphiMagic;

uses
  Forms,
  ufrmDelphiMagicMain in 'ufrmDelphiMagicMain.pas' {frmDelphiMagicMain},
  uButtonInterceptor in 'uButtonInterceptor.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmDelphiMagicMain, frmDelphiMagicMain);
  Application.Run;
end.
