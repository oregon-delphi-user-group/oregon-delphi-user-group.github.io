unit uButtonInterceptor;

interface


uses
  StdCtrls, SysUtils, DateUtils;

type
  TButton = class(StdCtrls.TButton)
  private
    FLastClickTime: TDateTime;
    FClickWaitSeconds: Integer;
  public
    procedure Click; override;
  public
    property ClickWaitSeconds: Integer read FClickWaitSeconds write FClickWaitSeconds;
  end;

implementation

uses
  Windows;

{ TButton }

procedure TButton.Click;
var
  ClickTime: TDateTime;
begin
  ClickTime := Now;

  if SecondsBetween(ClickTime, FLastClickTime) > ClickWaitSeconds then
    inherited
  else
    MessageBox(0, PChar('Double-clicking not allowed'), PChar('Notice!'), MB_OK + MB_ICONASTERISK + MB_TASKMODAL);

  FLastClickTime := ClickTime;
end;

end.
