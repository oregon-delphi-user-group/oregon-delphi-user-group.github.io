object frmDelphiMagicMain: TfrmDelphiMagicMain
  Left = 0
  Top = 0
  Caption = 'Delphi Magic!'
  ClientHeight = 349
  ClientWidth = 508
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  ShowHint = True
  OnCreate = FormCreate
  DesignSize = (
    508
    349)
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 96
    Top = 64
    Width = 31
    Height = 13
    Caption = 'Label1'
  end
  object Button1: TButton
    Left = 422
    Top = 8
    Width = 78
    Height = 25
    Hint = 'Click this button to add the selected string to the list below'
    CustomHint = BalloonHint1
    Anchors = [akTop, akRight]
    Caption = 'Add Strings'
    TabOrder = 0
    OnClick = Button1Click
  end
  object CheckBox1: TCheckBox
    Left = 24
    Top = 16
    Width = 177
    Height = 17
    Hint = 
      'This CheckBox is used by one of the strings in the ComboBox to t' +
      'he right'
    CustomHint = BalloonHint1
    Caption = 'A nifty but useless checkbox'
    TabOrder = 1
  end
  object cmbDateStuff: TComboBox
    Left = 296
    Top = 10
    Width = 123
    Height = 21
    Hint = 'the ComboBox allows selection of various pre-populated items'
    CustomHint = BalloonHint1
    Style = csDropDownList
    Anchors = [akLeft, akTop, akRight]
    ItemHeight = 13
    TabOrder = 2
    Items.Strings = (
      'days this year'
      'weeks this year'
      'this week number'
      'milliseconds today'
      'random from'
      'dupe string'
      'checkbox status')
  end
  object ProgressBar1: TProgressBar
    Left = 0
    Top = 332
    Width = 508
    Height = 17
    Hint = 'Control this ProgressBar with the TrackBar above'
    CustomHint = BalloonHint1
    Align = alBottom
    Position = 20
    TabOrder = 3
  end
  object TrackBar1: TTrackBar
    Left = 128
    Top = 260
    Width = 150
    Height = 45
    Hint = 
      'Slide this TrackBar back and forth to see the progress bar fill ' +
      'up or empty'
    CustomHint = BalloonHint1
    Position = 2
    TabOrder = 4
    OnChange = TrackBar1Change
  end
  object Button2: TButton
    Left = 24
    Top = 204
    Width = 75
    Height = 25
    Hint = 
      'If themes are enabled, the TaskDialog is a Vista-like dialog wit' +
      'h new features'
    CustomHint = BalloonHint1
    Caption = 'Task Dialog'
    TabOrder = 5
    OnClick = Button2Click
  end
  object LabeledEdit1: TLabeledEdit
    Left = 24
    Top = 104
    Width = 121
    Height = 21
    EditLabel.Width = 59
    EditLabel.Height = 13
    EditLabel.Caption = 'asdfasdadsf'
    EditLabel.Layout = tlBottom
    LabelPosition = lpBelow
    TabOrder = 6
  end
  object StringGrid1: TStringGrid
    Left = 296
    Top = 39
    Width = 204
    Height = 279
    ColCount = 1
    FixedCols = 0
    RowCount = 2
    Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine]
    TabOrder = 7
    ColWidths = (
      182)
  end
  object LinkLabel1: TLinkLabel
    Left = 115
    Top = 152
    Width = 163
    Height = 17
    Caption = 
      'click to launch <a href="http://corneliusconcepts.com">cornelius' +
      ' Concepts</a>'
    TabOrder = 8
  end
  object TaskDialog1: TTaskDialog
    Buttons = <>
    Caption = 'Delphi Magic!'
    ExpandButtonCaption = 'Details'
    ExpandedText = 
      'Here are details that can be listed in a field called, ExpandedT' +
      'ext, which looks like it can hold a really very long line.'
    ProgressBar.Position = 25
    RadioButtons = <>
    Text = 
      'This is the new Task Dialog button, a component which allows you' +
      ' to specify all the details of this dialog window at design time' +
      '.  Nice!'
    Title = 'Title Goes Here'
    Left = 48
    Top = 240
  end
  object BalloonHint1: TBalloonHint
    Delay = 200
    HideAfter = 3000
    Left = 216
    Top = 64
  end
end
