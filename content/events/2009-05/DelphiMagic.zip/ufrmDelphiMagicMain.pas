unit ufrmDelphiMagicMain;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, uButtonInterceptor, ExtCtrls, Buttons, ComCtrls, ActnMan,
  ActnColorMaps, Grids;

type
  TfrmDelphiMagicMain = class(TForm)
    Button1: TButton;
    CheckBox1: TCheckBox;
    cmbDateStuff: TComboBox;
    ProgressBar1: TProgressBar;
    TrackBar1: TTrackBar;
    Button2: TButton;
    TaskDialog1: TTaskDialog;
    BalloonHint1: TBalloonHint;
    LabeledEdit1: TLabeledEdit;
    StringGrid1: TStringGrid;
    LinkLabel1: TLinkLabel;
    Label1: TLabel;
    procedure TrackBar1Change(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ButtonedEdit1Click(Sender: TObject);
  end;

var
  frmDelphiMagicMain: TfrmDelphiMagicMain;

implementation

{$R *.dfm}

uses
  DateUtils, StrUtils;

procedure TfrmDelphiMagicMain.Button1Click(Sender: TObject);
begin
  case cmbDateStuff.ItemIndex of
    0: begin StringGrid1.RowCount := StringGrid1.RowCount + 1; StringGrid1.Cells[0, StringGrid1.RowCount - 1] := 'days this year = ' + IntToStr(DaysInYear(Now)); end;
    1: begin StringGrid1.rowcount := stringGrid1.RowCount + 1; Stringgrid1.Cells[0, stringgrid1.RowCount - 1] := 'weeks this year = ' + IntToStr(WeeksInYear(Now)); end;
    2: begin StringGrid1.rowcount := stringGrid1.Rowcount + 1; Stringgrid1.cells[0, stringgrid1.rowcount - 1] := 'this is week #' + IntToStr((WeekOfTheYear(Now))); end;
    3: begin StringGrid1.rowcount := stringGrid1.Rowcount + 1; Stringgrid1.cells[0, stringgrid1.rowcount - 1] := 'milliseconds today: ' + IntToStr(MilliSecondOfTheDay(Now)); end;
    4: begin StringGrid1.rowcount := stringGrid1.Rowcount + 1; Stringgrid1.cells[0, stringgrid1.rowcount - 1] := RandomFrom(['one', 'two', 'three', 'four', 'five', 'six', 'seven']); end;
    5: begin StringGrid1.rowcount := stringGrid1.Rowcount + 1; Stringgrid1.cells[0, stringgrid1.rowcount - 1] := DupeString('A', Random(15) + 1); end;
    6: begin StringGrid1.rowcount := stringGrid1.Rowcount + 1; Stringgrid1.cells[0, stringgrid1.rowcount - 1] := IfThen(CheckBox1.Checked, 'checked', 'NOT checked'); end;
  end;

end;

procedure TfrmDelphiMagicMain.Button2Click(Sender: TObject);
begin
  TaskDialog1.Execute;
end;

procedure TfrmDelphiMagicMain.ButtonedEdit1Click(Sender: TObject);
begin
  showmessage('where?');
end;

procedure TfrmDelphiMagicMain.FormCreate(Sender: TObject);
begin
  Randomize;
end;

procedure TfrmDelphiMagicMain.TrackBar1Change(Sender: TObject);
begin
  ProgressBar1.Position := TrackBar1.Position * 10;
end;

end.

