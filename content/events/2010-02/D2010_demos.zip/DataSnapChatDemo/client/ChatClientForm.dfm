object ChatClient: TChatClient
  Left = 0
  Top = 0
  Caption = 'Chat Client'
  ClientHeight = 597
  ClientWidth = 555
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object ChatRoom: TGroupBox
    Left = 8
    Top = 16
    Width = 537
    Height = 89
    Caption = 'Authentication'
    TabOrder = 1
    object ChatRoomName: TLabel
      Left = 16
      Top = 24
      Width = 57
      Height = 13
      Caption = 'Chat Room:'
    end
    object Label1: TLabel
      Left = 16
      Top = 56
      Width = 39
      Height = 13
      Caption = 'User Id:'
    end
    object ChatRoomEdit: TEdit
      Left = 79
      Top = 21
      Width = 338
      Height = 21
      TabOrder = 0
      Text = 'public'
    end
    object UserIdEdit: TEdit
      Left = 79
      Top = 53
      Width = 338
      Height = 21
      TabOrder = 1
      Text = 'john'
    end
    object Login: TButton
      Left = 439
      Top = 48
      Width = 75
      Height = 26
      Caption = 'Login'
      TabOrder = 3
      OnClick = LoginClick
    end
    object http: TCheckBox
      Left = 439
      Top = 25
      Width = 75
      Height = 17
      Caption = 'HTTP'
      TabOrder = 2
      OnClick = httpClick
    end
  end
  object ChatMessages: TMemo
    Left = 8
    Top = 111
    Width = 537
    Height = 338
    Enabled = False
    ScrollBars = ssBoth
    TabOrder = 2
  end
  object MessageGroupBox: TGroupBox
    Left = 8
    Top = 464
    Width = 537
    Height = 113
    Caption = 'Message'
    TabOrder = 0
    object MessageMemo: TMemo
      Left = 16
      Top = 16
      Width = 401
      Height = 86
      ScrollBars = ssBoth
      TabOrder = 0
    end
    object SendMessage: TButton
      Left = 439
      Top = 16
      Width = 75
      Height = 89
      Caption = 'Send'
      Enabled = False
      TabOrder = 1
      OnClick = SendMessageClick
    end
  end
  object TCPSQLConn: TSQLConnection
    ConnectionName = 'DSCONNECTION'
    DriverName = 'DataSnap'
    LoginPrompt = False
    Params.Strings = (
      '//DelegateConnection=DBXTraceConnection'
      'DriverName=DataSnap')
    Left = 168
    Top = 224
  end
  object HTTPSQLConn: TSQLConnection
    ConnectionName = 'DSHTTPCONNECTION'
    DriverName = 'DataSnap'
    LoginPrompt = False
    Params.Strings = (
      '//DelegateConnection=DBXTraceConnection'
      'CommunicationProtocol=http'
      'DriverName=DataSnap'
      'Port=8080')
    Left = 168
    Top = 288
  end
end
