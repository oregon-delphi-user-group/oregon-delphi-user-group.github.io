unit ChatClientForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, WideStrings, DbxDatasnap, DB, SqlExpr, ChatClientProxy, DBXJSON, DSHTTPLayer;

type
  TChatClient = class(TForm)
    ChatRoom: TGroupBox;
    ChatRoomName: TLabel;
    Label1: TLabel;
    ChatRoomEdit: TEdit;
    UserIdEdit: TEdit;
    Login: TButton;
    ChatMessages: TMemo;
    MessageGroupBox: TGroupBox;
    MessageMemo: TMemo;
    SendMessage: TButton;
    http: TCheckBox;
    TCPSQLConn: TSQLConnection;
    HTTPSQLConn: TSQLConnection;
    procedure FormCreate(Sender: TObject);
    procedure httpClick(Sender: TObject);
    procedure LoginClick(Sender: TObject);
    procedure SendMessageClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
    FClientProxy: TChatServerMethodsClient;
    FConnected: boolean;
    FCurrentConnection: TSQLConnection;
  private
    type TChatCallback = class(TDBXCallback)
      private
        FVCLThread: TThread;
      public
        constructor Create(vclThread: TThread);
        function Execute(const Arg: TJSONValue): TJSONValue; override;
    end;
    type TFormThread = class(TThread)
      private
        FVCLThread: TThread;
      public
        constructor Create;
      protected
        procedure Execute; override;
    end;

  private
    FThread: TFormThread;
  public
    { Public declarations }
    procedure LogMessage(const msg: String);

    destructor Destroy; override;
  end;

var
  ChatClient: TChatClient;

implementation

{$R *.dfm}

{ TChatClient.TFormThread }

constructor TChatClient.TFormThread.Create;
begin
  FVCLThread := TThread.CurrentThread;
  inherited Create(false);
end;

procedure TChatClient.TFormThread.Execute;
var
  conn: TSQLConnection;
  proxy: TChatServerMethodsClient;
begin
  conn := ChatClient.FCurrentConnection.CloneConnection;
  proxy := nil;
  try
    ChatClient.FConnected := true;

    TThread.Synchronize(FVCLThread, procedure begin
      ChatClient.Login.Caption := 'Logout';
      ChatClient.SendMessage.Enabled := true;
      ChatClient.http.Enabled := false;
    end);

    conn.Open;
    proxy := TChatServerMethodsClient.Create(conn.DBXConnection);
    proxy.LoginChatRoom(ChatClient.ChatRoomEdit.Text,
                        ChatClient.UserIdEdit.Text,
                        TChatCallback.Create(FVCLThread));
  finally
    proxy.Free;
    if conn <> nil then
      conn.Close;
    conn.Free;

    TThread.Synchronize(FVCLThread, procedure begin
      ChatClient.Login.Caption := 'Login';
      ChatClient.SendMessage.Enabled := false;
      ChatClient.http.Enabled := true;
    end);
    ChatClient.FConnected := false;
  end;
end;

{ TChatClient.TChatCallback }

constructor TChatClient.TChatCallback.Create(vclThread: TThread);
begin
  FVCLThread := vclThread;
end;

function TChatClient.TChatCallback.Execute(const Arg: TJSONValue): TJSONValue;
var
  Data: TJSONValue;
begin
  Data := TJSONValue(Arg.Clone);
  TThread.Queue(FVCLThread, procedure begin
     ChatClient.LogMessage(Format('%s - %s: %s',
                  [TJSONObject(data).Get(0).JsonValue.Value,
                   TJSONObject(data).Get(1).JsonValue.Value,
                   TJSONObject(data).Get(2).JsonValue.Value]));
     Data.Free;
  end);

  Result := TJSONObject.Create;
  TJSONObject(Result).AddPair(TJSONPair.Create('status', TJSONTrue.Create));
end;

{ TChatClient }

destructor TChatClient.Destroy;
begin
  FreeAndNil(FThread);
  FreeAndNil(FClientProxy);

  inherited;
end;

procedure TChatClient.FormClose(Sender: TObject; var Action: TCloseAction);
begin
 if FConnected then
 begin
   LoginClick(self);
 end;
end;

procedure TChatClient.FormCreate(Sender: TObject);
begin
  FConnected := false;
  FCurrentConnection := TCPSQLConn;
end;

procedure TChatClient.httpClick(Sender: TObject);
begin
  if FCurrentConnection.Connected then
    FCurrentConnection.Close;
  if HTTP.Checked then
    FCurrentConnection := HTTPSQLConn
  else
    FCurrentConnection := TCPSQLConn;
end;

procedure TChatClient.LoginClick(Sender: TObject);
begin
  if FConnected then
  begin
    // logout
    if FClientProxy = nil then
    begin
      FCurrentConnection.Open;
      FClientProxy := TChatServerMethodsClient.Create(FCurrentConnection.DBXConnection);
    end;
    FClientProxy.Logout(ChatRoomEdit.Text, UserIdEdit.Text);
    FreeAndNil(FClientProxy);
    FCurrentConnection.Close;
  end
  else
  begin
    // login
    if (ChatRoomEdit.Text <> '') and (UserIdEdit.Text <> '') then
    begin
      FreeAndNil(FThread);
      FThread := TFormThread.Create;
    end
    else
      MessageDlg('Both chat room and user id need to be filled in', mtInformation,
        [mbOK], -1);
  end;
end;

procedure TChatClient.LogMessage(const msg: String);
begin
  ChatMessages.Lines.Add(msg);
end;

procedure TChatClient.SendMessageClick(Sender: TObject);
begin
  if MessageMemo.Text <> '' then
  begin
    if FClientProxy = nil then
    begin
      FCurrentConnection.Open;
      FClientProxy := TChatServerMethodsClient.Create(FCurrentConnection.DBXConnection);
    end;
    if FClientProxy.SendMessage(ChatRoomEdit.Text, UserIdEdit.Text, MessageMemo.Text) then
      MessageMemo.Clear;
  end;
end;

end.
