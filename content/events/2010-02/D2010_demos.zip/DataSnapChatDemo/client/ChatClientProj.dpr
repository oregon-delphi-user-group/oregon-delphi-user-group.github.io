program ChatClientProj;

uses
  Forms,
  ChatClientForm in 'ChatClientForm.pas' {ChatClient},
  ChatClientProxy in 'ChatClientProxy.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TChatClient, ChatClient);
  Application.Run;
end.
