//
// Created by the DataSnap proxy generator.
//

unit ChatClientProxy;

interface

uses DBXCommon, DBXJSON, Classes, SysUtils, DB, SqlExpr, DBXDBReaders;

type
  TChatServerMethodsClient = class
  private
    FDBXConnection: TDBXConnection;
    FInstanceOwner: Boolean;
    FSendMessageCommand: TDBXCommand;
    FLoginChatRoomCommand: TDBXCommand;
    FLogoutCommand: TDBXCommand;
  public
    constructor Create(ADBXConnection: TDBXConnection); overload;
    constructor Create(ADBXConnection: TDBXConnection; AInstanceOwner: Boolean); overload;
    destructor Destroy; override;
    function SendMessage(ChatRoom: string; UserId: string; sentence: string): Boolean;
    procedure LoginChatRoom(ChatRoom: string; UserId: string; callback: TDBXCallback);
    function Logout(ChatRoom: string; UserId: string): Boolean;
  end;

implementation

function TChatServerMethodsClient.SendMessage(ChatRoom: string; UserId: string; sentence: string): Boolean;
begin
  if FSendMessageCommand = nil then
  begin
    FSendMessageCommand := FDBXConnection.CreateCommand;
    FSendMessageCommand.CommandType := TDBXCommandTypes.DSServerMethod;
    FSendMessageCommand.Text := 'TChatServerMethods.SendMessage';
    FSendMessageCommand.Prepare;
  end;
  FSendMessageCommand.Parameters[0].Value.SetWideString(ChatRoom);
  FSendMessageCommand.Parameters[1].Value.SetWideString(UserId);
  FSendMessageCommand.Parameters[2].Value.SetWideString(sentence);
  FSendMessageCommand.ExecuteUpdate;
  Result := FSendMessageCommand.Parameters[3].Value.GetBoolean;
end;

procedure TChatServerMethodsClient.LoginChatRoom(ChatRoom: string; UserId: string; callback: TDBXCallback);
begin
  if FLoginChatRoomCommand = nil then
  begin
    FLoginChatRoomCommand := FDBXConnection.CreateCommand;
    FLoginChatRoomCommand.CommandType := TDBXCommandTypes.DSServerMethod;
    FLoginChatRoomCommand.Text := 'TChatServerMethods.LoginChatRoom';
    FLoginChatRoomCommand.Prepare;
  end;
  FLoginChatRoomCommand.Parameters[0].Value.SetWideString(ChatRoom);
  FLoginChatRoomCommand.Parameters[1].Value.SetWideString(UserId);
  FLoginChatRoomCommand.Parameters[2].Value.SetCallbackValue(callback);
  FLoginChatRoomCommand.ExecuteUpdate;
end;

function TChatServerMethodsClient.Logout(ChatRoom: string; UserId: string): Boolean;
begin
  if FLogoutCommand = nil then
  begin
    FLogoutCommand := FDBXConnection.CreateCommand;
    FLogoutCommand.CommandType := TDBXCommandTypes.DSServerMethod;
    FLogoutCommand.Text := 'TChatServerMethods.Logout';
    FLogoutCommand.Prepare;
  end;
  FLogoutCommand.Parameters[0].Value.SetWideString(ChatRoom);
  FLogoutCommand.Parameters[1].Value.SetWideString(UserId);
  FLogoutCommand.ExecuteUpdate;
  Result := FLogoutCommand.Parameters[2].Value.GetBoolean;
end;


constructor TChatServerMethodsClient.Create(ADBXConnection: TDBXConnection);
begin
  inherited Create;
  if ADBXConnection = nil then
    raise EInvalidOperation.Create('Connection cannot be nil.  Make sure the connection has been opened.');
  FDBXConnection := ADBXConnection;
  FInstanceOwner := True;
end;


constructor TChatServerMethodsClient.Create(ADBXConnection: TDBXConnection; AInstanceOwner: Boolean);
begin
  inherited Create;
  if ADBXConnection = nil then
    raise EInvalidOperation.Create('Connection cannot be nil.  Make sure the connection has been opened.');
  FDBXConnection := ADBXConnection;
  FInstanceOwner := AInstanceOwner;
end;


destructor TChatServerMethodsClient.Destroy;
begin
  FreeAndNil(FSendMessageCommand);
  FreeAndNil(FLoginChatRoomCommand);
  FreeAndNil(FLogoutCommand);
  inherited;
end;

end.

