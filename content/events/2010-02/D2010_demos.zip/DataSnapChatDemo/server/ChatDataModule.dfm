object ChatServer: TChatServer
  OldCreateOrder = False
  Height = 150
  Width = 215
end
