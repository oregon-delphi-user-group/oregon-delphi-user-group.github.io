unit ChatDataModule;

interface

uses
  SysUtils, Classes, DBXJSON, Generics.Collections, SyncObjs;

const
  ADMIN = 'admin';
  SENDER = 'sender';
  TIMESTAMP = 'timestamp';
  CONTENT = 'content';

type
  TParticipantStatus = (psCreated, psInRoom, psTerminated, psClosing);

  TChatRoomParticipant = class
  private
    /// <summary>participant id</summary>
    FId: string;
    /// <summary>callback instance</summary>
    FMessage: TDBXCallback;
    /// <summary>error code related to the previous message, 0 means success</summary>
    FError: integer;
    /// <summary>error message</summary>
    FErrorMessage: string;
    /// <summary>instance status</summary>
    FStatus: TParticipantStatus;
    /// <summary>signaled if the participant needs to be terminated while status in room</summary>
    FTerminate: TEvent;

    FSender: TJSONPair;
    FTimestamp: TJSONPair;
    FContent: TJSONPair;

  protected
    procedure SetStringValue(pair: TJSONPair; const value: string);
    property Status: TParticipantStatus read FStatus write FStatus;
    property ErrorCode: integer read FError;
    property ErrorMessage: string read FErrorMessage;

  public
    constructor Create(id: string; callback: TDBXCallback);
    destructor Destroy; override;

    /// <summary>Sends a message back to the participant</summary>
    function Message(timestamp: string; sender: string; content: string): boolean;
    /// <summary>Terminates the participation in the chat room</summary>
    procedure Terminate;
    /// <summary>clears the error message</summary>
    procedure ResetError;
  end;

  TChatRoomStatus = (crsEmpty, crsActive, crsTerminated);

  TChatRoom = class
  private
    /// <summary>participant instances</summary>
    FParticipants: TDictionary<string, TChatRoomParticipant>;
    /// <summary>signaled if class is terminated</summary>
    FTerminate: TEvent;
    /// <summary>status</summary>
    FStatus: TChatRoomStatus;
    /// active participants
    FCount: Integer;
  protected
    property Count: Integer read FCount write FCount;
  public
    constructor Create; virtual;
    destructor Destroy; override;

    /// <summary>try to add a new participant, return false if already exists</summary>
    function TryAddParticipant(const id: String; participant: TChatRoomParticipant): boolean;  virtual;
    /// <summary>DS thread method</summary>
    procedure EnterChatRoom(participant: TChatRoomParticipant); virtual;
    /// <summary>broadcast a sentence to all participants</summary>
    procedure Speak(const Id: String; const sentence: String); virtual;
    /// <summary>terminate class</summary>
    procedure Terminate; virtual;
    /// <summary>returns true if there is an active participant</summary>
    function HasParticipant(const Id: string): boolean; virtual;
    /// <summary>returns the participant</summary>
    function GetParticipant(const Id: string): TChatRoomParticipant; virtual;
    /// <summary>remove participant</summary>
    procedure RemoveParticipant(const Id: string); virtual;

    property Status: TChatRoomStatus read FStatus;
  end;

  TChatServer = class(TDataModule)
  private
    { Private declarations }
    /// <summary>current rooms</summary>
    FRooms: TDictionary<string, TChatRoom>;
    /// <summary>used to synchronize pieces subject to multithreaded access</summary>
    FCriticalSection: TCriticalSection;

  protected
    function GetRoom(const roomId: string): TChatRoom;

  public
    { Public declarations }
    constructor Create(owner: TComponent); override;
    destructor Destroy; override;

    ///  <summary>Creates a TChatRoom for given id</summary>
    function CreateRoom(const roomId: string): boolean; overload;
    function CreateRoom(const roomId: string; room: TChatRoom): boolean; overload;
    ///  <summary>Closes a chat room and frees the resources</summary>
    function TerminateRoom(const roomId: string): boolean;
    ///  <summary>Removes a room from catalog</summary>
    function RemoveRoom(const roomId: string): boolean;
    function TerminateParticipant(const roomId: string; const Id: string): boolean;
    function TryJoinRoom(const roomId: string; const userId: string; const userCallback: TDBXCallback): boolean;
    function TryBroadcastSentence(const roomId: string; const userId: string; const sentence: string): boolean;
  end;

var
  ChatServer: TChatServer;

implementation

{$R *.dfm}

{ TChatRoomParticipant }

constructor TChatRoomParticipant.Create(id: string; callback: TDBXCallback);
begin
  FId := id;
  FMessage := callback;
  FStatus := psCreated;
  FError := 0;

  FTerminate := TEvent.Create(nil, false, false, '', false);

  FSender := TJSONPair.Create(SENDER, '');
  FSender.Owned := false;
  FContent := TJSONPair.Create(CONTENT, '');
  FContent.Owned := false;
  FTimestamp := TJSONPair.Create(TIMESTAMP, '');
  FTimestamp.Owned := false;
end;

destructor TChatRoomParticipant.Destroy;
begin
  FStatus := psClosing;
  FreeAndNil(FTerminate);

  FreeAndNil(FSender);
  FreeAndNil(FContent);
  FreeAndNil(FTimestamp);

  inherited;
end;

function TChatRoomParticipant.Message(timestamp, sender,
  content: string): boolean;
var
  msg: TJSONObject;
  response: TJSONObject;
begin
  msg := TJSONObject.Create;
  SetStringValue(FTimestamp, timestamp);
  SetStringValue(FSender, sender);
  SetStringValue(FContent, content);

  msg.AddPair(FTimestamp);
  msg.AddPair(FSender);
  msg.AddPair(FContent);

  try
    response := TJSONObject(FMessage.Execute(msg));
    try
      if response.Get(0).JsonValue is TJSONFalse then
      begin
        FError := TJSONNumber(response.Get(1).JsonValue).AsInt;
        FErrorMessage := response.Get(2).JsonValue.Value;
        exit(false);
      end;

      exit(true);
    finally
      response.Free;
    end;
  except on e: Exception do
  begin
    FError := -1;
    FErrorMessage := e.Message;
    exit(false);
  end;
  end;
end;

procedure TChatRoomParticipant.ResetError;
begin
  FErrorMessage := '';
  FError := 0;
end;

procedure TChatRoomParticipant.SetStringValue(pair: TJSONPair;
  const value: string);
begin
  pair.JsonValue.Free;
  pair.JsonValue := TJSONString.Create(value);
end;

procedure TChatRoomParticipant.Terminate;
begin
  FStatus := psTerminated;
  FTerminate.SetEvent;
end;

{ TChatRoom }

constructor TChatRoom.Create;
begin
  FStatus := crsEmpty;
  FTerminate := TEvent.Create(nil, false, false, '', false);
  FParticipants := TDictionary<string, TChatRoomParticipant>.Create;
  FCount := 0;
end;

destructor TChatRoom.Destroy;
begin
  Terminate;
  FreeAndNil(FTerminate);
  FreeAndNil(FParticipants);

  inherited;
end;

procedure TChatRoom.EnterChatRoom(participant: TChatRoomParticipant);
var
  event: THandleObject;
  hArray: THandleObjectArray;
begin
  Speak(ADMIN, 'Welcome ' + participant.FId);

  SetLength(hArray, 2);
  hArray[0] := FTerminate;
  hArray[1] := participant.FTerminate;
  TEvent.WaitForMultiple(hArray, INFINITE, false, event, false, 2);
  if event = FTerminate then
    FTerminate.SetEvent;
  if FStatus <> crsTerminated then
    Speak(ADMIN, 'Bye ' + participant.FId);
end;

function TChatRoom.GetParticipant(const Id: string): TChatRoomParticipant;
begin
  if FParticipants.ContainsKey(Id) then
    exit(FParticipants.Items[id]);
end;

function TChatRoom.HasParticipant(const Id: string): boolean;
begin
  exit(FParticipants.ContainsKey(id));
end;

procedure TChatRoom.RemoveParticipant(const Id: string);
begin
  FParticipants.Remove(Id);
end;

procedure TChatRoom.Speak(const Id, sentence: String);
var
  keys: TDictionary<string, TChatRoomParticipant>.TKeyCollection;
  keyEnum: TDictionary<string, TChatRoomParticipant>.TKeyEnumerator;
  ts: string;
  participant: TChatRoomParticipant;
begin
  ts := DatetimeToStr(now);
  keys := FParticipants.Keys;
  keyEnum := keys.GetEnumerator;
  try
      while keyEnum.MoveNext do
      begin
        participant := GetParticipant(keyEnum.Current);
        if not participant.Message(ts, Id, Sentence) then
        begin
          ChatServer.TryBroadcastSentence(ADMIN, Id, Format('%d: %s', [participant.ErrorCode, participant.ErrorMessage]));
          participant.ResetError;
        end;
      end;
  finally
    FreeAndNil(keyEnum);
  end;
end;

procedure TChatRoom.Terminate;
begin
  Speak(ADMIN, 'Chat room terminated');
  FStatus := crsTerminated;
  FTerminate.SetEvent;
end;

function TChatRoom.TryAddParticipant(const id: String;
  participant: TChatRoomParticipant): boolean;
begin
  if FParticipants.ContainsKey(id) then
    exit(false);

  participant.Status := psInRoom;
  FStatus := crsActive;
  FParticipants.Add(id, participant);

  exit(true);
end;

{ TChatServer }

constructor TChatServer.Create(owner: TComponent);
begin
  inherited;

  FCriticalSection := TCriticalSection.Create;
  FRooms := TDictionary<string, TChatRoom>.Create;
end;

function TChatServer.CreateRoom(const roomId: string): boolean;
begin
  FCriticalSection.Acquire;
  try
    if FRooms.ContainsKey(roomId) then
      exit(false);
    FRooms.Add(roomId, TChatRoom.Create);
    exit(true);
  finally
    FCriticalSection.Release;
  end;
end;

function TChatServer.CreateRoom(const roomId: string; room: TChatRoom): boolean;
begin
  FCriticalSection.Acquire;
  try
    if FRooms.ContainsKey(roomId) then
      exit(false);
    FRooms.Add(roomId, room);
    exit(true);
  finally
    FCriticalSection.Release;
  end;
end;

destructor TChatServer.Destroy;
begin
  // assums all rooms were removed
  FreeAndNil(FRooms);
  FreeAndNil(FCriticalSection);
  inherited;
end;

function TChatServer.GetRoom(const roomId: string): TChatRoom;
begin
  if FRooms.ContainsKey(roomId) then
    exit(FRooms[roomId])
  else
    exit(nil);
end;

function TChatServer.RemoveRoom(const roomId: string): boolean;
begin
  FCriticalSection.Acquire;
  try
    if not FRooms.ContainsKey(roomId) then
      exit(false);
    FRooms.Remove(roomId);
    exit(true);
  finally
    FCriticalSection.Release;
  end;
end;

function TChatServer.TerminateParticipant(const roomId, Id: string): boolean;
var
  room: TChatRoom;
  participant: TChatRoomParticipant;
begin
  FCriticalSection.Acquire;
  try
    room := GetRoom(roomId);
    if room <> nil then
    begin
      participant := room.GetParticipant(Id);
      if participant <> nil then
      begin
        participant.Terminate;
        exit(true);
      end
    end;
    exit(false);
  finally
    FCriticalSection.Release;
  end;
end;

function TChatServer.TerminateRoom(const roomId: string): boolean;
var
  room: TChatRoom;
begin
  FCriticalSection.Acquire;
  try
    if FRooms.ContainsKey(roomId) then
    begin
      room := GetRoom(roomId);
      room.Terminate;
      FRooms.Remove(roomId);
    end
    else
      exit(false);
  finally
    FCriticalSection.Release;
  end;

  while room.Count > 0 do Sleep(100);
  FreeAndNil(room);
  exit(true);
end;

function TChatServer.TryBroadcastSentence(const roomId, userId,
  sentence: string): boolean;
var
  room: TChatRoom;
begin
  FCriticalSection.Acquire;
  try
    room := GetRoom(roomId);
    if (room <> nil) and (room.HasParticipant(userId)) then
    begin
      room.Speak(userId, sentence);
      exit(true);
    end;
    exit(false);
  finally
    FCriticalSection.Release;
  end;
end;

function TChatServer.TryJoinRoom(const roomId, userId: string;
  const userCallback: TDBXCallback): boolean;
var
  room: TChatRoom;
  participant: TChatRoomParticipant;
begin
  FCriticalSection.Acquire;
  try
    room := GetRoom(roomId);
    if room = nil then
      exit(false);

    participant := TChatRoomParticipant.Create(userId, userCallback);
    if not room.TryAddParticipant(userId, participant) then
      exit(false);
  finally
    FCriticalSection.Release;
  end;

  try
    Inc(room.FCount);
    room.EnterChatRoom(participant);
    exit(true);
  finally
    FCriticalSection.Acquire;
    try
      room.RemoveParticipant(userId);
      FreeAndNil(participant);
    finally
      FCriticalSection.Release;
      Dec(room.FCount);
    end;
  end;
end;

end.
