object ChatRoomForm: TChatRoomForm
  Left = 0
  Top = 0
  Caption = 'Log Server'
  ClientHeight = 341
  ClientWidth = 643
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Visible = True
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object Log: TMemo
    Left = 8
    Top = 8
    Width = 627
    Height = 281
    ScrollBars = ssBoth
    TabOrder = 0
  end
  object Terminate: TButton
    Left = 560
    Top = 308
    Width = 75
    Height = 25
    Caption = 'Terminate'
    TabOrder = 1
    OnClick = TerminateClick
  end
  object Clear: TButton
    Left = 8
    Top = 308
    Width = 75
    Height = 25
    Caption = 'Clear'
    TabOrder = 2
    OnClick = ClearClick
  end
end
