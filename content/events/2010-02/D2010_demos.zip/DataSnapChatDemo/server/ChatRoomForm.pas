unit ChatRoomForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TLocalParticipant = class;

  TChatRoomForm = class(TForm)
    Log: TMemo;
    Terminate: TButton;
    Clear: TButton;
    procedure ClearClick(Sender: TObject);
    procedure TerminateClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
    FRoomName: String;
    FAdmin: TLocalParticipant;

    procedure SetRoomName(const name: string);
  public
    { Public declarations }
    constructor Create(owner: TComponent; const RoomName: string); reintroduce;

    procedure LogMessage(msg: string);
    procedure RegisterAdmin;

    property RoomName: string read FRoomName write SetRoomName;
  end;

  TLocalParticipant = class(TThread)
  private
    FRoomName: string;
    FForm: TChatRoomForm;
  protected
    procedure Execute; override;
  public
    constructor Create(const RoomName: string; roomForm: TChatRoomForm);
  end;

implementation

{$R *.dfm}

uses DBXJSON, ChatDataModule;

type
  TLocalCallback = class(TDBXCallback)
  private
    FForm: TChatRoomForm;
  public
    constructor Create(form: TChatRoomForm);

    function Execute(const Arg: TJSONValue): TJSONValue; override;
  end;

procedure TChatRoomForm.ClearClick(Sender: TObject);
begin
  Log.Lines.Clear;
end;

constructor TChatRoomForm.Create(owner: TComponent; const RoomName: string);
begin
  inherited Create(owner);
  SetRoomName(RoomName);
end;

procedure TChatRoomForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  ChatServer.TerminateRoom(RoomName);
  FreeAndNil(FAdmin);
end;

procedure TChatRoomForm.LogMessage(msg: string);
begin
  Log.Lines.Add(msg);
end;

procedure TChatRoomForm.RegisterAdmin;
begin
  // register the admin
  FAdmin := TLocalParticipant.Create(RoomName, self);
end;

procedure TChatRoomForm.SetRoomName(const name: string);
begin
  FRoomName := name;
  Caption := name;
end;

procedure TChatRoomForm.TerminateClick(Sender: TObject);
begin
  Close();
end;

{ TLocalCallback }

constructor TLocalCallback.Create(form: TChatRoomForm);
begin
  FForm := form;
end;

function TLocalCallback.Execute(const Arg: TJSONValue): TJSONValue;
var
  obj: TJSONObject;
begin
  obj := TJSONObject(Arg);
  FForm.LogMessage(Format('%s - %s:%s', [obj.Get(0).JsonValue.Value,
                                         obj.Get(1).JsonValue.Value,
                                         obj.Get(2).JsonValue.Value]));
  Result := TJSONObject.Create;
  TJSONObject(Result).AddPair(TJSONPair.Create('status', TJSONTrue.Create));
end;

{ TLocalParticipant }

procedure TLocalParticipant.Execute;
var
  callback: TLocalCallback;
begin
  callback := TLocalCallback.Create(FForm);
  if ChatServer.TryJoinRoom(FRoomName, ADMIN, callback) then
  begin
    // remove participant
  end;
  FreeAndNil(callback);
end;

constructor TLocalParticipant.Create(const RoomName: string; roomForm: TChatRoomForm);
begin
  FRoomName := RoomName;
  FForm := roomForm;

  inherited Create(false);
end;

end.
