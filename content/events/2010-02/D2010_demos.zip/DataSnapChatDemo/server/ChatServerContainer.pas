unit ChatServerContainer;

interface

uses
  SysUtils, Classes, 
  DSTCPServerTransport,
  DSHTTPCommon, DSHTTP,
  DSServer, DSCommonServer; 

type
  TServerContainer2 = class(TDataModule)
    DSServer1: TDSServer;
    DSTCPServerTransport1: TDSTCPServerTransport;
    DSHTTPService1: TDSHTTPService;
    DSHTTPServiceAuthenticationManager1: TDSHTTPServiceAuthenticationManager;
    DSServerClass1: TDSServerClass;
    procedure DSServerClass1GetClass(DSServerClass: TDSServerClass;
      var PersistentClass: TPersistentClass);
    procedure DataModuleDestroy(Sender: TObject);
  private
    { Private declarations }
  public
  end;

var
  ServerContainer2: TServerContainer2;

implementation

uses Windows, ChatServerMethods, ChatDataModule;

{$R *.dfm}

procedure TServerContainer2.DataModuleDestroy(Sender: TObject);
begin
  DSServer1.Stop;
end;

procedure TServerContainer2.DSServerClass1GetClass(
  DSServerClass: TDSServerClass; var PersistentClass: TPersistentClass);
begin
  PersistentClass := ChatServerMethods.TChatServerMethods;
end;

end.




