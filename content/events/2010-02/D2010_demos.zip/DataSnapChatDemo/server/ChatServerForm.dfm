object Form9: TForm9
  Left = 0
  Top = 0
  Caption = 'Chat Server'
  ClientHeight = 395
  ClientWidth = 426
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnActivate = FormActivate
  OnClose = FormClose
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object ChatRoomBox: TGroupBox
    Left = 24
    Top = 8
    Width = 377
    Height = 65
    Caption = 'Chat Room Creation'
    TabOrder = 0
    object ChatRoomLabel: TLabel
      Left = 16
      Top = 24
      Width = 57
      Height = 13
      Caption = 'Chat Room:'
    end
    object ChatRoomName: TEdit
      Left = 79
      Top = 21
      Width = 202
      Height = 21
      TabOrder = 0
      Text = 'public'
    end
    object CreateChat: TButton
      Left = 287
      Top = 19
      Width = 75
      Height = 25
      Caption = 'Create'
      TabOrder = 1
      OnClick = CreateChatClick
    end
  end
  object LogBox: TGroupBox
    Left = 24
    Top = 96
    Width = 377
    Height = 273
    Caption = 'Log'
    TabOrder = 1
    object Log: TMemo
      Left = 16
      Top = 24
      Width = 346
      Height = 209
      ScrollBars = ssBoth
      TabOrder = 0
    end
    object ClearLog: TButton
      Left = 287
      Top = 239
      Width = 75
      Height = 25
      Caption = 'Clear Log'
      TabOrder = 1
      OnClick = ClearLogClick
    end
  end
end
