unit ChatServerForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ChatDataModule;

type
  TAdminChatRoom = class(TChatRoom)
    function TryAddParticipant(const id: String; participant: TChatRoomParticipant): boolean;  override;
    procedure EnterChatRoom(participant: TChatRoomParticipant); override;
    procedure Speak(const Id: String; const sentence: String); override;
    procedure Terminate; override;
    function HasParticipant(const Id: string): boolean; override;
    function GetParticipant(const Id: string): TChatRoomParticipant; override;
    procedure RemoveParticipant(const Id: string); override;

  end;

  TForm9 = class(TForm)
    ChatRoomBox: TGroupBox;
    ChatRoomLabel: TLabel;
    ChatRoomName: TEdit;
    CreateChat: TButton;
    Log: TMemo;
    LogBox: TGroupBox;
    ClearLog: TButton;
    procedure ClearLogClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure CreateChatClick(Sender: TObject);
    procedure FormActivate(Sender: TObject);
  private
    { Private declarations }
    FAdminRoom: TAdminChatRoom;
  public
    { Public declarations }
    procedure LogMessage(const msg: String);
  end;

var
  Form9: TForm9;

implementation

{$R *.dfm}

uses ChatRoomForm;

procedure TForm9.ClearLogClick(Sender: TObject);
begin
  Log.Lines.Clear;
end;

procedure TForm9.CreateChatClick(Sender: TObject);
begin
  if ChatRoomName.Text <> '' then
  begin
    // create the room
    if ChatServer.CreateRoom(ChatRoomName.Text) then
    begin
      // create visual form
      TChatRoomForm.Create(self, ChatRoomName.Text).RegisterAdmin;
    end
    else
      MessageDlg('Room already exists', mtError, [mbOK], -1);
  end;
end;

procedure TForm9.FormActivate(Sender: TObject);
begin
  ChatServer.CreateRoom(ADMIN, FAdminRoom);
end;

procedure TForm9.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  ChatServer.RemoveRoom(ADMIN);
  FreeAndNil(FAdminRoom);
end;

procedure TForm9.FormCreate(Sender: TObject);
begin
  FAdminRoom := TAdminChatRoom.Create;
end;

procedure TForm9.LogMessage(const msg: String);
begin
  Log.Lines.Add(msg);
end;

{ TAdminChatRoom }

procedure TAdminChatRoom.EnterChatRoom(participant: TChatRoomParticipant);
begin
end;

function TAdminChatRoom.GetParticipant(const Id: string): TChatRoomParticipant;
begin
  exit(nil);
end;

function TAdminChatRoom.HasParticipant(const Id: string): boolean;
begin
  exit(false);
end;

procedure TAdminChatRoom.RemoveParticipant(const Id: string);
begin
end;

procedure TAdminChatRoom.Speak(const Id, sentence: String);
begin
  Form9.LogMessage(Format('%s - %s:%s', [DateTimeToStr(Now), Id, sentence]));
end;

procedure TAdminChatRoom.Terminate;
begin
end;

function TAdminChatRoom.TryAddParticipant(const id: String;
  participant: TChatRoomParticipant): boolean;
begin
  exit(false);
end;

end.




