unit ChatServerMethods;

interface

uses
  SysUtils, Classes, DSServer, DBXJSON;

type
  TChatServerMethods = class(TDSServerModule)
  private
    { Private declarations }
    FLogin: boolean;
    FUserId: String;
    FChatRoom: String;

  public
    { Public declarations }
    function SendMessage(const ChatRoom: string; const UserId: string; sentence: string): boolean;
    procedure LoginChatRoom(const ChatRoom: string; const UserId: string; callback: TDBXCallback);
    function Logout(const ChatRoom: string; const UserId: string): boolean;

    property Login: boolean read FLogin;
    property UserId: string read FUserId;
    property ChatRoom: string read FChatRoom;
  end;

var
  ServerMethods1: TChatServerMethods;

implementation

{$R *.dfm}

uses ChatDataModule;

{ TServerMethods1 }

procedure TChatServerMethods.LoginChatRoom(const ChatRoom, UserId: string;
  callback: TDBXCallback);
begin
  FLogin := true;
  FUserId := UserId;
  FChatRoom := ChatRoom;
  if not ChatServer.TryJoinRoom(ChatRoom, UserId, callback) then
    raise Exception.Create('Cannot join room');
end;

function TChatServerMethods.Logout(const ChatRoom: string; const UserId: string): boolean;
begin
  exit(ChatServer.TerminateParticipant(ChatRoom, UserId));
end;

function TChatServerMethods.SendMessage(const ChatRoom: string; const UserId: string; sentence: string): boolean;
begin
  exit(ChatServer.TryBroadcastSentence(ChatRoom, UserId, sentence));
end;

end.




