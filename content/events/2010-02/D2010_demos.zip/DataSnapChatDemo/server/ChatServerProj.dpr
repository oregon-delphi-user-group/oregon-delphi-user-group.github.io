program ChatServerProj;

uses
  Forms,
  ChatServerForm in 'ChatServerForm.pas' {Form9},
  ChatServerMethods in 'ChatServerMethods.pas' {ServerMethods1: TDSServerModule},
  ChatServerContainer in 'ChatServerContainer.pas' {ServerContainer2: TDataModule},
  ChatDataModule in 'ChatDataModule.pas' {ChatServer: TDataModule},
  ChatRoomForm in 'ChatRoomForm.pas' {Form10};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TForm9, Form9);
  Application.CreateForm(TChatServer, ChatServer);
  Application.CreateForm(TChatServerMethods, ServerMethods1);
  Application.CreateForm(TServerContainer2, ServerContainer2);
//  Application.CreateForm(TChatRoomForm, Form10);
  Application.Run;
end.




