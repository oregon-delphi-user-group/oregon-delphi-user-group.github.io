object Form4: TForm4
  Left = 757
  Top = 336
  Caption = 'DataSnap Client'
  ClientHeight = 123
  ClientWidth = 408
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesigned
  PixelsPerInch = 96
  TextHeight = 16
  object Label1: TLabel
    Left = 15
    Top = 19
    Width = 105
    Height = 16
    Caption = 'Type a a message'
  end
  object Button1: TButton
    Left = 272
    Top = 25
    Width = 128
    Height = 37
    Caption = 'Send Text'
    TabOrder = 1
    OnClick = Button1Click
  end
  object Edit1: TEdit
    Left = 15
    Top = 38
    Width = 251
    Height = 24
    TabOrder = 0
  end
  object Button2: TButton
    Left = 272
    Top = 68
    Width = 128
    Height = 44
    BiDiMode = bdLeftToRight
    Caption = 'Encrypt Text (Local)'
    ParentBiDiMode = False
    TabOrder = 2
    WordWrap = True
    OnClick = Button2Click
  end
  object SQLConnection1: TSQLConnection
    ConnectionName = 'DSCONNECTION'
    DriverName = 'DataSnap'
    LoginPrompt = False
    Params.Strings = (
      '//DelegateConnection=DBXTraceConnection'
      'DriverName=DataSnap'
      'HostName=localhost'
      'port=213'
      'User_Name=sysdba'
      'Password=masterkey')
    Left = 48
    Top = 72
  end
  object SqlServerMethod1: TSqlServerMethod
    GetMetadata = False
    Params = <
      item
        DataType = ftWideString
        Precision = 2000
        Name = 'Msg'
        ParamType = ptInput
      end
      item
        DataType = ftWideString
        Precision = 2000
        Name = 'ReturnParameter'
        ParamType = ptResult
        Size = 2000
        Value = ''
      end>
    SQLConnection = SQLConnection1
    ServerMethodName = 'TDSServerModule1.Echo'
    Left = 96
    Top = 72
  end
end
