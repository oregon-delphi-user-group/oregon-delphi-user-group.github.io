unit ClientMain;

interface

uses
  Windows,
  Messages,
  SysUtils,
  Variants,
  Classes,
  Graphics,
  Controls,
  Forms,
  DBXCompressionFilter,
  DSFEncryptClasses,
  DbxTransport,
  DBXSOcketChannelNative,
  Dialogs,
  WideStrings,
  DB,
  SqlExpr,
  DbxDatasnap,
  FMTBcd,
  StdCtrls;

type
  TForm4 = class(TForm)
    SQLConnection1: TSQLConnection;
    SqlServerMethod1: TSqlServerMethod;
    Button1: TButton;
    Edit1: TEdit;
    Label1: TLabel;
    Button2: TButton;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);

  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form4: TForm4;

Const
  C1 = 52845;
  C2 = 11719;

implementation

{$R *.dfm}

procedure TForm4.Button1Click(Sender: TObject);
begin
  SqlServerMethod1.ServerMethodName := 'TDSServerModule1.Echo';
  SqlServerMethod1.Params[0].AsString := Edit1.Text;
  SqlServerMethod1.ExecuteMethod;
  ShowMessage('Received: ' + SqlServerMethod1.Params[1].AsString);
end;

procedure TForm4.Button2Click(Sender: TObject);
var
  EnDecrypt: TTransportEncryptFilter;
  EnDecryptedBytes: TBytes;
  OriginalValue: String;
begin
  EnDecrypt := TTransportEncryptFilter.Create;
  OriginalValue := Edit1.Text;

  if Button2.Caption = 'Encrypt Text (Local)' then
  begin
     Button2.Caption := 'Dencrypt Text (Local)';
     EnDecryptedBytes := EnDecrypt.ProcessInput(BytesOf(OriginalValue));
  end
  else
  begin
     Button2.Caption := 'Encrypt Text (Local)';
     EnDecryptedBytes := EnDecrypt.ProcessOutput(BytesOf(OriginalValue));
  end;

  Edit1.Text := StringOf(EnDecryptedBytes);
  EnDecrypt.Free;
end;

end.
