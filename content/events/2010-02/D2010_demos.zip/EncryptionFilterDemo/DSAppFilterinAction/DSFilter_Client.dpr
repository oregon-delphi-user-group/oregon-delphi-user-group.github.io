program DSFilter_Client;

uses
  Forms,
  ClientMain in 'ClientMain.pas' {Form4},
  DSFEncryptClasses in '..\DSFilterEncrypt\DSFEncryptClasses.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TForm4, Form4);
  Application.Run;
end.
