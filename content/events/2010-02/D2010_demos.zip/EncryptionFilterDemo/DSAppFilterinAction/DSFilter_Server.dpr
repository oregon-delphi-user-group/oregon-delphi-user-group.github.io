program DSFilter_Server;

uses
  Forms,
  ServerMain in 'ServerMain.pas' {MainForm},
  ServerModule in 'ServerModule.pas' {DSServerModule1: TDSServerModule},
  DSFEncryptClasses in '..\DSFilterEncrypt\DSFEncryptClasses.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TMainForm, MainForm);
  Application.CreateForm(TDSServerModule1, DSServerModule1);
  Application.Run;
end.
