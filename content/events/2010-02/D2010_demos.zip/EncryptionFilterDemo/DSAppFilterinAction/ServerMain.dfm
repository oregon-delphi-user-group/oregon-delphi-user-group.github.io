object MainForm: TMainForm
  Left = 0
  Top = 0
  Caption = 'DataSnap Server with Filters'
  ClientHeight = 190
  ClientWidth = 249
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 32
    Top = 29
    Width = 88
    Height = 13
    Caption = 'Registered Filters:'
  end
  object ListBox1: TListBox
    Left = 24
    Top = 48
    Width = 193
    Height = 73
    ItemHeight = 13
    TabOrder = 0
  end
  object DSServer1: TDSServer
    AutoStart = True
    HideDSAdmin = False
    Left = 40
    Top = 144
  end
  object DSTCPServerTransport1: TDSTCPServerTransport
    Port = 213
    PoolSize = 0
    Server = DSServer1
    BufferKBSize = 32
    Filters = <
      item
        FilterId = 'ZLibCompression'
      end>
    Left = 128
    Top = 144
  end
  object DSServerClass1: TDSServerClass
    OnGetClass = DSServerClass1GetClass
    Server = DSServer1
    LifeCycle = 'Session'
    Left = 208
    Top = 144
  end
end
