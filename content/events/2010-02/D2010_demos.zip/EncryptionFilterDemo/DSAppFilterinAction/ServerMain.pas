unit ServerMain;

interface

uses
  Windows,
  Messages,
  SysUtils,
  Variants,
  Classes,
  Graphics,
  Controls,
  StdCtrls,
  Dialogs,
  DSCommonServer,
  DSTCPServerTransport,
  DSServer,
  DBXTransport,
  Forms,
  DSFEncryptClasses,
  DbxCompressionFilter,
  ServerModule;

type
  TMainForm = class(TForm)
    DSServer1: TDSServer;
    DSTCPServerTransport1: TDSTCPServerTransport;
    DSServerClass1: TDSServerClass;
    ListBox1: TListBox;
    Label1: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure DSServerClass1GetClass(DSServerClass: TDSServerClass;
      var PersistentClass: TPersistentClass);

  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  MainForm: TMainForm;

implementation

{$R *.dfm}

procedure TMainForm.DSServerClass1GetClass(DSServerClass: TDSServerClass;
  var PersistentClass: TPersistentClass);
begin
  PersistentClass := TDSServerModule1;
end;

procedure TMainForm.FormCreate(Sender: TObject);
var
  i: integer;
begin
  // ZLibCompression Filter is added at design-time

  // To add during run-time:
  // DSTCPServerTransport1.Filters.AddFilter('ZLibCompression');
  i := DSTCPServerTransport1.Filters.AddFilter('EncryptionFilter');
  DSTCPServerTransport1.Filters.GetFilter(i).SetParameterValue
    ('Key', '100');

  for i := 0 to DSTCPServerTransport1.Filters.Count - 1 do
    ListBox1.Items.Add(DSTCPServerTransport1.Filters.GetFilter(i).Id);

end;

end.
