object DSServerModule1: TDSServerModule1
  OldCreateOrder = False
  Height = 266
  Width = 359
end
