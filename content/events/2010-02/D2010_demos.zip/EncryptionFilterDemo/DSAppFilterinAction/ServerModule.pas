unit ServerModule;

interface

uses
  SysUtils, Classes, DSServer;

type
  TDSServerModule1 = class(TDSServerModule)
  private
    { Private declarations }
  public
    { Public declarations }
    function Echo(Msg: String): String;
  end;

var
  DSServerModule1: TDSServerModule1;

implementation

{$R *.dfm}

{ TDSServerModule1 }

function TDSServerModule1.Echo(Msg: String): String;
begin
  Result := Msg;
end;

end.