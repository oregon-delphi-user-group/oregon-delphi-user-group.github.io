unit DSFEncryptClasses;

interface

uses
  Windows,
  SysUtils,
  Dialogs,
  Generics.Collections,
  Generics.Defaults,
  DBXPlatform,
  DBXTransport;

type
  TMyEncrypt = class
  protected
    function Encrypt(const Data: TBytes; EncKey: Integer): TBytes;
    function Decrypt(const Data: TBytes; EncKey: Integer): TBytes;

  public
    constructor Create;
  end;

  TTransportEncryptFilter = class(TTransportFilter)
  private
    FEncrypt: TMyEncrypt;
    FParameters: TDictionary<String, String>;

  protected
    function GetParameters: TDBXStringArray; override;
    function GetUserParameters: TDBXStringArray; override;

  public
    function GetParameterValue(const ParamName: UnicodeString): UnicodeString;
      override;
    function SetParameterValue(const ParamName: UnicodeString;
      const ParamValue: UnicodeString): Boolean; override;
    constructor Create; override;
    destructor Destroy; override;
    function ProcessInput(const Data: TBytes): TBytes; override;
    function ProcessOutput(const Data: TBytes): TBytes; override;
    function Id: UnicodeString; override;
  end;

const
  EncryptFilterName = 'EncryptionFilter';
  EncryptKey = 'Key';

implementation

{ TMyEncrypt }

constructor TMyEncrypt.Create;
begin
  inherited Create;
end;

// Encryption and Decryption method has the same code
// The reason of that is for better understand when you see the code
function TMyEncrypt.Decrypt(const Data: TBytes; EncKey: Integer): TBytes;
var
  i: Integer;
begin

  Result := Data;

  for i := 0 to Length(Data) - 1 do
    Result[i] := Byte(Chr(not(Ord(Data[i]) + EncKey)));

end;

function TMyEncrypt.Encrypt(const Data: TBytes; EncKey: Integer): TBytes;
var
  i: Integer;
begin

  Result := Data;

  for i := 0 to Length(Data) - 1 do
    Result[i] := Byte(Chr(not(Ord(Data[i]) + EncKey)));

end;

{ TTransportEncryptFilter }

function TTransportEncryptFilter.GetUserParameters: TDBXStringArray;
//var
//  Key: String;
//  i: Integer;
begin
  SetLength(Result, 1);
  Result[0] := EncryptKey;

  // SetLength(Result, FParameters.Count);
  //
  // i := 0;
  // for Key in FParameters.Keys do
  // begin
  // if Key <> EncryptKey then
  // begin
  // Result[i] := Key;
  // Inc(i);
  // end;
  // end;
  //
end;

function TTransportEncryptFilter.GetParameters: TDBXStringArray;
begin
  SetLength(Result, 1);
  Result[0] := EncryptKey;
end;

function TTransportEncryptFilter.GetParameterValue
  (const ParamName: UnicodeString): UnicodeString;
begin
  FParameters.TryGetValue(ParamName, Result);

  if ( ParamName = EncryptKey ) and ( Result = '' ) then
     Result := '0';
end;

function TTransportEncryptFilter.SetParameterValue
  (const ParamName, ParamValue: UnicodeString): Boolean;
begin
  FParameters.AddOrSetValue(ParamName, ParamValue);
  Result := True;
end;

constructor TTransportEncryptFilter.Create;
begin
  inherited Create;

  FEncrypt := TMyEncrypt.Create;
  FParameters := TDictionary<String, String>.Create;

end;

destructor TTransportEncryptFilter.Destroy;
begin
  FreeAndNil(FEncrypt);
  inherited Destroy;
end;

function TTransportEncryptFilter.ProcessInput(const Data: TBytes): TBytes;
begin
  OutputDebugString(PWideChar('Encrypted - ' + Stringof(Data)));
  Result := FEncrypt.Encrypt
    (Data, StrToInt(Self.GetParameterValue(EncryptKey)));
end;

function TTransportEncryptFilter.ProcessOutput(const Data: TBytes): TBytes;
begin
  OutputDebugString(PWideChar('Decrypted - ' + Stringof(Data)));
  Result := FEncrypt.Decrypt
    (Data, StrToInt(Self.GetParameterValue(EncryptKey)));
end;

function TTransportEncryptFilter.Id: UnicodeString;
begin
  Result := EncryptFilterName;
end;

initialization

TTransportFilterFactory.RegisterFilter(EncryptFilterName,
  TTransportEncryptFilter);

finalization

TTransportFilterFactory.UnregisterFilter(EncryptFilterName);

end.
