unit DBXMetadataHelper;

interface

uses
  Forms, SysUtils, SqlExpr,
  DbxCommon, DbxMetaDataProvider, DBXDataExpressMetaDataProvider,
  DbxInterbase, DbxBlackfishSQL, DbxClient, DBXDataStoreMetaData;

function DBXGetMetaProvider(const AConnection: TDBXConnection):  TDBXDataExpressMetaDataProvider;
procedure InitConnection(conn: TSQLConnection; dbname: string; CreateDB: Boolean);
function GetDatabaseDirectory : String;
procedure AddPrimaryKey(Provider: TDBXDataExpressMetaDataProvider; TableName, ColumnName: string);
procedure AddUniqueIndex(Provider: TDBXDataExpressMetaDataProvider; TableName, ColumnName: string);
procedure AddForeignKey(Provider: TDBXDataExpressMetaDataProvider; TableName, ColumnName, PrimaryTableName, PrimaryColumn: string);

implementation

function DBXGetMetaProvider(const AConnection: TDBXConnection):  TDBXDataExpressMetaDataProvider;
var
  Provider: TDBXDataExpressMetaDataProvider;
begin
  Provider := TDBXDataExpressMetaDataProvider.Create;
  try
    Provider.Connection := AConnection;
    Provider.Open;
  except
    FreeAndNil(Provider);
    raise;
  end;

  Result := Provider;
end;

procedure InitConnection(conn: TSQLConnection; dbname: string; CreateDB: Boolean);
begin
  conn.DriverName := 'BLACKFISHSQL';
  conn.Params.Add(TDBXPropertyNames.DriverName+'=BLACKFISHSQL');
  conn.Params.Add(TDBXPropertyNames.HostName+'=localhost');
  conn.Params.Add(TDBXPropertyNames.Database+'=' + GetDatabaseDirectory + dbname);
  conn.Params.Add(TDBXPropertyNames.UserName+'=sysdba');
  conn.Params.Add(TDBXPropertyNames.Password+'=masterkey');
  conn.LoginPrompt := false;
  if (CreateDB) then
    conn.Params.Add('create=true');
  conn.Open;
end;

function GetDatabaseDirectory : String;
begin
  Result := GetCurrentDir;
  if Result[Length(Result)] <> '\' then
     Result := Result + '\';
  Result := Result + 'Database\';

end;

procedure AddPrimaryKey(Provider: TDBXDataExpressMetaDataProvider; TableName, ColumnName: string);
var
  index: TDBXMetaDataIndex;
begin
  index:=TDBXMetaDataIndex.Create;
  index.TableName:=tableName;
  index.AddColumn(columnName);

  Provider.CreatePrimaryKey(index);
  index.Free;
end;

procedure AddUniqueIndex(Provider: TDBXDataExpressMetaDataProvider; TableName, ColumnName: string);
var
  index: TDBXMetaDataIndex;
begin
  index := TDBXMetaDataIndex.Create;
  index.TableName := TableName;
  index.AddColumn(ColumnName);

  Provider.CreateUniqueIndex(index);
  index.Free;
end;

procedure AddForeignKey(Provider: TDBXDataExpressMetaDataProvider; TableName, ColumnName, PrimaryTableName, PrimaryColumn: string);
var
  key: TDBXMetaDataForeignKey;
begin
  key:=TDBXMetaDataForeignKey.Create;
  key.PrimaryTableName:=primaryTableName;
  key.TableName:=tableName;
  key.AddReference(columnName,primaryColumn);

  provider.CreateForeignKey(key);
  key.Free;
end;

end.
