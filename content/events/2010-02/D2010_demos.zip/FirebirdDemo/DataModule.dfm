object DMData: TDMData
  OldCreateOrder = False
  Height = 469
  Width = 717
  object CdsBiolife: TClientDataSet
    Aggregates = <>
    Params = <>
    ProviderName = 'BioProvider'
    Left = 216
    Top = 112
    object CdsBiolifeSPECIESNO: TFloatField
      DisplayLabel = 'Specie ID'
      FieldName = 'SPECIES NO'
      Required = True
    end
    object CdsBiolifeCATEGORY: TStringField
      DisplayLabel = 'Category'
      FieldName = 'CATEGORY'
      Size = 15
    end
    object CdsBiolifeCOMMON_NAME: TStringField
      DisplayLabel = 'Common Name'
      FieldName = 'COMMON_NAME'
      Size = 30
    end
    object CdsBiolifeSPECIESNAME: TStringField
      DisplayLabel = 'Species Name'
      FieldName = 'SPECIES NAME'
      Size = 40
    end
    object CdsBiolifeLENGTH_CM_: TFloatField
      DisplayLabel = 'Length (cm)'
      FieldName = 'LENGTH _CM_'
    end
    object CdsBiolifeLENGTH_IN: TFloatField
      DisplayLabel = 'Length_In'
      FieldName = 'LENGTH_IN'
    end
    object CdsBiolifeNOTES: TMemoField
      DisplayLabel = 'Notes'
      FieldName = 'NOTES'
      BlobType = ftMemo
      Size = 1
    end
    object CdsBiolifeGRAPHIC: TBlobField
      DisplayLabel = 'Graphic'
      FieldName = 'GRAPHIC'
      Size = 1
    end
  end
  object SQLNewTable: TSQLDataSet
    CommandText = 'Select * from TABLE_DEMO'
    DbxCommandType = 'Dbx.SQL'
    MaxBlobSize = 1
    Params = <>
    SQLConnection = DBPictures
    Left = 119
    Top = 189
  end
  object ProvideNewTable: TDataSetProvider
    DataSet = SQLNewTable
    Options = [poIncFieldProps, poUseQuoteChar]
    Left = 122
    Top = 256
  end
  object CDSNewTable: TClientDataSet
    Aggregates = <>
    Params = <>
    ProviderName = 'ProvideNewTable'
    Left = 26
    Top = 256
    object CDSNewTableFIELDBIGINT: TLargeintField
      FieldName = 'FIELDBIGINT'
      Required = True
    end
    object CDSNewTableFIELDVARCHAR: TStringField
      FieldName = 'FIELDVARCHAR'
      Required = True
      Size = 150
    end
    object CDSNewTableFIELDBLOG: TBlobField
      FieldName = 'FIELDBLOG'
      Required = True
      Size = 1
    end
    object CDSNewTableFIELDDOUBLE: TFloatField
      FieldName = 'FIELDDOUBLE'
    end
  end
  object BioProvider: TDataSetProvider
    DataSet = SqlBIOLIFE
    Options = [poIncFieldProps, poUseQuoteChar]
    Left = 128
    Top = 112
  end
  object DBPictures: TSQLConnection
    ConnectionName = 'Pictures Demo'
    DriverName = 'FIREBIRD'
    GetDriverFunc = 'getSQLDriverINTERBASE'
    LibraryName = 'dbxfb.dll'
    LoginPrompt = False
    Params.Strings = (
      'drivername=FIREBIRD'
      'Database=C:\Program Files\Firebird\Firebird_2_1\bin\dbdemos.fdb'
      'User_Name=SYSDBA')
    VendorLib = 'fbclient.DLL'
    Left = 42
    Top = 114
  end
  object SqlBIOLIFE: TSQLDataSet
    CommandText = 'Select * from BIOLIFE'
    DbxCommandType = 'Dbx.SQL'
    MaxBlobSize = 1
    Params = <>
    SQLConnection = DBPictures
    Left = 85
    Top = 45
    object SqlBIOLIFESPECIESNO: TFloatField
      DisplayLabel = 'Specie ID'
      FieldName = 'SPECIES NO'
      Required = True
    end
    object SqlBIOLIFECATEGORY: TStringField
      DisplayLabel = 'Category'
      FieldName = 'CATEGORY'
      Size = 15
    end
    object SqlBIOLIFECOMMON_NAME: TStringField
      DisplayLabel = 'Common Name'
      FieldName = 'COMMON_NAME'
      Size = 30
    end
    object SqlBIOLIFESPECIESNAME: TStringField
      DisplayLabel = 'Species Name'
      FieldName = 'SPECIES NAME'
      Size = 40
    end
    object SqlBIOLIFELENGTH_CM_: TFloatField
      DisplayLabel = 'Length (cm)'
      FieldName = 'LENGTH _CM_'
    end
    object SqlBIOLIFELENGTH_IN: TFloatField
      DisplayLabel = 'Length_In'
      FieldName = 'LENGTH_IN'
    end
    object SqlBIOLIFENOTES: TMemoField
      DisplayLabel = 'Notes'
      FieldName = 'NOTES'
      BlobType = ftMemo
      Size = 1
    end
    object SqlBIOLIFEGRAPHIC: TBlobField
      DisplayLabel = 'Graphic'
      FieldName = 'GRAPHIC'
      Size = 1
    end
  end
end
