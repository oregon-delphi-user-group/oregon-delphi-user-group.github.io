unit DataModule;

interface

uses
  SysUtils, Classes, FMTBcd, WideStrings, DBXFirebird, DB, SqlExpr, Provider,
  DBClient;

type
  TDMData = class(TDataModule)
    CdsBiolife: TClientDataSet;
    CdsBiolifeSPECIESNO: TFloatField;
    CdsBiolifeCATEGORY: TStringField;
    CdsBiolifeCOMMON_NAME: TStringField;
    CdsBiolifeSPECIESNAME: TStringField;
    CdsBiolifeLENGTH_CM_: TFloatField;
    CdsBiolifeLENGTH_IN: TFloatField;
    CdsBiolifeNOTES: TMemoField;
    CdsBiolifeGRAPHIC: TBlobField;
    SQLNewTable: TSQLDataSet;
    ProvideNewTable: TDataSetProvider;
    CDSNewTable: TClientDataSet;
    CDSNewTableFIELDBIGINT: TLargeintField;
    CDSNewTableFIELDVARCHAR: TStringField;
    CDSNewTableFIELDBLOG: TBlobField;
    CDSNewTableFIELDDOUBLE: TFloatField;
    BioProvider: TDataSetProvider;
    DBPictures: TSQLConnection;
    SqlBIOLIFE: TSQLDataSet;
    SqlBIOLIFESPECIESNO: TFloatField;
    SqlBIOLIFECATEGORY: TStringField;
    SqlBIOLIFECOMMON_NAME: TStringField;
    SqlBIOLIFESPECIESNAME: TStringField;
    SqlBIOLIFELENGTH_CM_: TFloatField;
    SqlBIOLIFELENGTH_IN: TFloatField;
    SqlBIOLIFENOTES: TMemoField;
    SqlBIOLIFEGRAPHIC: TBlobField;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  DMData: TDMData;

implementation

{$R *.dfm}

end.
