unit MainForm;

interface

uses Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, pngimage, ExtCtrls, StdCtrls, WideStrings, DBXFirebird, FMTBcd,
  DBCtrls, DBClient, Provider, SqlExpr, ComCtrls, Mask, DbxMetaDataHelper,
  DbxCommon, DbxMetaDataProvider, DBXDataExpressMetaDataProvider,
  DbxBlackfishSQL, DBXDataStoreMetaData, Grids, DBGrids, DB;

type
  TForm1 = class(TForm)
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    DSBioLife: TDataSource;
    Label2: TLabel;
    DBEdit1: TDBEdit;
    Label3: TLabel;
    DBEdit2: TDBEdit;
    Label4: TLabel;
    DBEdit3: TDBEdit;
    Label5: TLabel;
    DBEdit4: TDBEdit;
    Label6: TLabel;
    DBEdit5: TDBEdit;
    Label7: TLabel;
    DBEdit6: TDBEdit;
    Label8: TLabel;
    DBMemo1: TDBMemo;
    DBImage1: TDBImage;
    DBNavigator1: TDBNavigator;
    LETableName: TLabeledEdit;
    Button1: TButton;
    Image1: TImage;
    DSNewTable: TDataSource;
    DBGrid1: TDBGrid;
    DBImage2: TDBImage;
    procedure CdsBiolifeAfterPost(DataSet: TDataSet);
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure CDSNewTableReconcileError(DataSet: TCustomClientDataSet;
      E: EReconcileError; UpdateKind: TUpdateKind;
      var Action: TReconcileAction);

  private
    { Private declarations }
    procedure PopulateTable;

  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

uses DataModule;
{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
var
  Provider: TDBXDataExpressMetaDataProvider;

  MyTable: TDBXMetaDataTable;
  PrimaryKey: TDBXMetaDataIndex;

  IntField: TDBXInt64Column;
  VarcharField: TDBXUnicodeVarCharColumn;
  BlobField: TDBXBinaryLongColumn;
  DoubleField: TDBXDoubleColumn;

begin
  Provider := DBXGetMetaProvider(DMData.DBPictures.DBXConnection);

  // Dropping Table
  Provider.DropTable(LETableName.Text);

  With DMData do
  begin

    // My table
    MyTable := TDBXMetaDataTable.Create;
    try
      MyTable.TableName := LETableName.Text;

      IntField := TDBXInt64Column.Create('FIELDBIGINT');
      IntField.Nullable := false;
      MyTable.AddColumn(IntField);

      VarcharField := TDBXUnicodeVarCharColumn.Create('FIELDVARCHAR', 50);
      VarcharField.Nullable := false;
      MyTable.AddColumn(VarcharField);

      BlobField := TDBXBinaryLongColumn.Create('FIELDBLOG');
      BlobField.Nullable := false;
      MyTable.AddColumn(BlobField);

      DoubleField := TDBXDoubleColumn.Create('FIELDDOUBLE');
      DoubleField.DefaultValue := '100';
      MyTable.AddColumn(TDBXDoubleColumn.Create('FIELDDOUBLE'));

      Provider.CreateTable(MyTable);

      PrimaryKey := TDBXMetaDataIndex.Create;

      try
        PrimaryKey.TableName := LETableName.Text;
        PrimaryKey.AddColumn(IntField.ColumnName);
        Provider.CreatePrimaryKey(PrimaryKey);

      finally
        PrimaryKey.Free;
      end;
    finally

      FreeAndNil(Provider);
      FreeAndNil(MyTable);

      PopulateTable();

    end;
  end;
end;

procedure TForm1.CdsBiolifeAfterPost(DataSet: TDataSet);
begin
  DMData.CdsBiolife.ApplyUpdates(-1);
end;

procedure TForm1.CDSNewTableReconcileError(DataSet: TCustomClientDataSet;
  E: EReconcileError; UpdateKind: TUpdateKind; var Action: TReconcileAction);
begin
  ShowMessage(E.Message);
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  Application.CreateForm(TDMData, DMData);
  DMData.CdsBiolife.Open;
end;

procedure TForm1.PopulateTable;
var
  i: Integer;
begin
  With DMData do
  begin

    SQLNewTable.Close;
    SQLNewTable.CommandText := 'Select * from ' + LETableName.Text;
    SQLNewTable.Open;

    CDSNewTable.Open;

    CdsBiolife.First;
    i := 1;
    while not CdsBiolife.Eof do
    begin
      CDSNewTable.Insert;
      CDSNewTableFIELDBIGINT.AsInteger := i;
      CDSNewTableFIELDVARCHAR.Value := CdsBiolifeCOMMON_NAME.Value;
      CDSNewTableFIELDBLOG.Value := CdsBiolifeGRAPHIC.Value;
      CDSNewTableFIELDDOUBLE.Value := CdsBiolifeLENGTH_CM_.Value;
      CDSNewTable.Post;

      Inc(i);

      CdsBiolife.Next;
    end;
    CDSNewTable.ApplyUpdates(-1);
  end;

end;

end.
