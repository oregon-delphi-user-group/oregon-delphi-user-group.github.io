program rtti_browser;
// Browse & Attributes

uses
  Forms,
  Form_Main in 'Form_Main.pas' {MainForm};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
