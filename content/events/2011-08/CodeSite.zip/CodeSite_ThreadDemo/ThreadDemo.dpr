program ThreadDemo;

uses
  ExceptionLog,
  Forms,
  ThreadSortForm in 'ThreadSortForm.pas' {FrmMain},
  SortThreads in 'SortThreads.pas';

{$R *.RES}

begin
  Application.Title := 'CodeSite Threading Demo';
  Application.CreateForm(TFrmMain, FrmMain);
  Application.Run;
end.
