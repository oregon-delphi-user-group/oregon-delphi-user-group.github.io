unit ThreadSortForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, CodeSiteLogging;

type
  TFrmMain = class(TForm)
    StartBtn: TButton;
    BubbleSortBox: TPaintBox;
    SelectionSortBox: TPaintBox;
    QuickSortBox: TPaintBox;
    Label1: TLabel;
    Bevel1: TBevel;
    Bevel2: TBevel;
    Bevel3: TBevel;
    Label2: TLabel;
    Label3: TLabel;
    btnReset: TButton;
    procedure BubbleSortBoxPaint(Sender: TObject);
    procedure SelectionSortBoxPaint(Sender: TObject);
    procedure QuickSortBoxPaint(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure StartBtnClick(Sender: TObject);
    procedure btnResetClick(Sender: TObject);
  private
    ThreadsRunning: Integer;
    procedure RandomizeArrays;
    procedure ThreadDone(Sender: TObject);
  public
    CSBubble: TCodeSiteLogger;
    procedure PaintArray(Box: TPaintBox; const A: array of Integer);
  end;

var
  FrmMain: TFrmMain;

implementation

uses
  SortThreads;

{$R *.dfm}

type
  PSortArray = ^TSortArray;
  TSortArray =  array[0..114] of Integer;

const
  BubbleSortColor    = $002896FF;
  SelectionSortColor = clGreen;
  QuickSortColor     = clBlue;

var
  ArraysRandom: Boolean;
  BubbleSortArray, SelectionSortArray, QuickSortArray: TSortArray;

{ TThreadSortForm }

procedure TFrmMain.PaintArray(Box: TPaintBox; const A: array of Integer);
var
  I: Integer;
begin
  with Box do
  begin
    case Tag of
      1: Canvas.Pen.Color := BubbleSortColor;
      2: Canvas.Pen.Color := SelectionSortColor;
      3: Canvas.Pen.Color := QuickSortColor;
    end;

    for I := Low(A) to High(A) do PaintLine(Canvas, I, A[I]);
  end;
end;

procedure TFrmMain.btnResetClick(Sender: TObject);
begin
  RandomizeArrays;
end;

procedure TFrmMain.BubbleSortBoxPaint(Sender: TObject);
begin
  PaintArray(BubbleSortBox, BubbleSortArray);
end;

procedure TFrmMain.SelectionSortBoxPaint(Sender: TObject);
begin
  PaintArray(SelectionSortBox, SelectionSortArray);
end;

procedure TFrmMain.QuickSortBoxPaint(Sender: TObject);
begin
  PaintArray(QuickSortBox, QuickSortArray);
end;

procedure TFrmMain.FormCreate(Sender: TObject);
begin
  Left := ( Screen.Width - Width ) div 2;
  Top := ( Screen.Height - Height ) div 3;


  CSBubble := TCodeSiteLogger.Create( Self );
  CSBubble.Category := 'BubbleSort';
  CSBubble.ConnectUsingTcp;
  RandomizeArrays;
end;

procedure TFrmMain.StartBtnClick(Sender: TObject);
begin
  RandomizeArrays;
  ThreadsRunning := 3;
  with TBubbleSort.Create( BubbleSortBox, BubbleSortColor, BubbleSortArray) do
    OnTerminate := ThreadDone;
  with TSelectionSort.Create( SelectionSortBox, SelectionSortColor, SelectionSortArray ) do
    OnTerminate := ThreadDone;
  with TQuickSort.Create( QuickSortBox, QuickSortColor, QuickSortArray ) do
    OnTerminate := ThreadDone;
  StartBtn.Enabled := False;
end;

procedure TFrmMain.RandomizeArrays;
var
  I: Integer;
begin
  if not ArraysRandom then
  begin
    Randomize;
    for I := Low(BubbleSortArray) to High(BubbleSortArray) do
      BubbleSortArray[I] := Random(170);
    SelectionSortArray := BubbleSortArray;
    QuickSortArray := BubbleSortArray;
    ArraysRandom := True;
    Repaint;
  end;
end;

procedure TFrmMain.ThreadDone(Sender: TObject);
begin
  Dec(ThreadsRunning);
  if ThreadsRunning = 0 then
  begin
    StartBtn.Enabled := True;
    ArraysRandom := False;
  end;
end;

end.
