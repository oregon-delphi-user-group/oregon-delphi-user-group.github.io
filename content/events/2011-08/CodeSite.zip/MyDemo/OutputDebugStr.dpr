program OutputDebugStr;

uses
  Forms,
  ufrmOD in 'ufrmOD.pas' {frmOD};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmOD, frmOD);
  Application.Run;
end.
