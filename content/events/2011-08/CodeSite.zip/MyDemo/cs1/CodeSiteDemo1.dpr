program CodeSiteDemo1;

uses
  Forms,
  ufrmCS1 in 'ufrmCS1.pas' {frmCS1};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmCS1, frmCS1);
  Application.Run;
end.
