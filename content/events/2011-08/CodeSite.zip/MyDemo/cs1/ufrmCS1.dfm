object frmCS1: TfrmCS1
  Left = 0
  Top = 0
  Caption = 'CodeSite - First Stab'
  ClientHeight = 336
  ClientWidth = 507
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 120
  TextHeight = 16
  object Label1: TLabel
    Left = 40
    Top = 24
    Width = 77
    Height = 16
    Caption = 'Enter a string'
  end
  object lblCount: TLabel
    Left = 40
    Top = 280
    Width = 50
    Height = 16
    Caption = 'No items'
  end
  object ListBox1: TListBox
    Left = 328
    Top = 48
    Width = 161
    Height = 249
    TabOrder = 0
  end
  object Edit1: TEdit
    Left = 40
    Top = 43
    Width = 145
    Height = 24
    TabOrder = 1
  end
  object btnAdd: TButton
    Left = 40
    Top = 73
    Width = 75
    Height = 25
    Caption = '&Add'
    TabOrder = 2
    OnClick = btnAddClick
  end
  object Button1: TButton
    Left = 42
    Top = 104
    Width = 75
    Height = 25
    Caption = '&Add'
    TabOrder = 3
    OnClick = Button1Click
  end
end
