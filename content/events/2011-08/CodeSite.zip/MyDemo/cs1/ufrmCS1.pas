unit ufrmCS1;

interface

uses
  Windows, Messages, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TfrmCS1 = class(TForm)
    ListBox1: TListBox;
    Edit1: TEdit;
    Label1: TLabel;
    btnAdd: TButton;
    lblCount: TLabel;
    Button1: TButton;
    procedure btnAddClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private
    procedure ClearEdit;
    procedure UpdateCount;
  end;

var
  frmCS1: TfrmCS1;

implementation

{$R *.dfm}

uses
  {$IFDEF UseCodeSite} CodeSiteLogging, {$ENDIF}
  SysUtils;

procedure TfrmCS1.btnAddClick(Sender: TObject);
begin
  {$IFDEF UseCodeSite}CodeSite.EnterMethod(Self, 'btnAddClick');{$ENDIF}

  if Length(edit1.Text) > 0 then begin
    {$IFDEF UseCodeSite} CodeSite.Send('edit1.text', edit1.text); {$ENDIF}
    ListBox1.Items.Add(edit1.Text);
    ClearEdit;
    UpdateCount;
  end;

  {$IFDEF UseCodeSite}CodeSite.ExitMethod(Self, 'btnAddClick');{$ENDIF}
end;

procedure TfrmCS1.Button1Click(Sender: TObject);
begin
  {$IFDEF UseCodeSite}CodeSite.EnterMethod(Self, 'Button1Click');{$ENDIF}



  {$IFDEF UseCodeSite}CodeSite.ExitMethod(Self, 'Button1Click');{$ENDIF}
end;

procedure TfrmCS1.ClearEdit;
begin
  {$IFDEF UseCodeSite}CodeSite.EnterMethod(Self, 'ClearEdit');{$ENDIF}

  Edit1.Text := EmptyStr;

  {$IFDEF UseCodeSite}CodeSite.ExitMethod(Self, 'ClearEdit');{$ENDIF}
end;

procedure TfrmCS1.UpdateCount;
begin
  {$IFDEF UseCodeSite}CodeSite.EnterMethod(Self, 'UpdateCount');{$ENDIF}

  lblCount.Caption := IntToStr(ListBox1.Items.Count) + ' items';
  {$IFDEF UseCodeSite} CodeSite.Send('items', ListBox1.Items); {$ENDIF}

  {$IFDEF UseCodeSite}CodeSite.ExitMethod(Self, 'UpdateCount');{$ENDIF}
end;

end.










