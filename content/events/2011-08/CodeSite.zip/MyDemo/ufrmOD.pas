unit ufrmOD;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TfrmOD = class(TForm)
    ListBox1: TListBox;
    Edit1: TEdit;
    Label1: TLabel;
    btnAdd: TButton;
    lblCount: TLabel;
    procedure btnAddClick(Sender: TObject);
  private
    procedure ClearEdit;
    procedure UpdateCount;
    procedure ShowListBoxItems;
  end;

var
  frmOD: TfrmOD;

implementation

{$R *.dfm}

procedure TfrmOD.btnAddClick(Sender: TObject);
begin
  OutputDebugString('Enter > btnAddClick');

  if Length(edit1.Text) > 0 then begin
    ListBox1.Items.Add(edit1.Text);
    ClearEdit;
    UpdateCount;
    edit1.SetFocus;
  end;

  OutputDebugString('Exit < btnAddClick');
end;

procedure TfrmOD.ClearEdit;
begin
  OutputDebugString('Enter > ClearEdit');

  Edit1.Text := EmptyStr;

  OutputDebugString('Exit < ClearEdit');
end;

procedure TfrmOD.ShowListBoxItems;
begin
  OutputDebugString('Enter > ShowListBoxItems');
  OutputDebugString(ListBox1.Items.GetText);
  OutputDebugString('Exit < ShowListBoxItems');
end;

procedure TfrmOD.UpdateCount;
begin
  OutputDebugString('Enter > UpdateCount');

  lblCount.Caption := IntToStr(ListBox1.Items.Count) + ' items';
  ShowListBoxItems;

  OutputDebugString('Exit < UpdateCount');
end;

end.
