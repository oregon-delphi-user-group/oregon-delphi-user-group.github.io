/* This unit is the screen where all the action takes place. */

import React, { useEffect, useState } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
  ScrollView,
  Alert,
  Linking,
  TextInput,
  PermissionsAndroid,
  Platform,
  Keyboard,  
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import * as IntentLauncher from 'expo-intent-launcher'; // Import IntentLauncher to handle phone calls

const App = () => {
  const [data, setData] = useState(null); // Ensuring no rendering before data is available
  const [expanded, setExpanded] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filteredData, setFilteredData] = useState(null);
  const [lastNameFilter, setLastNameFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('-');

  useEffect(() => {
    fetch('https://YOUR_JSON_URL')
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then((json) => {
        // Check if the variable "json" exists and is an array.
        // This ensures that we only process valid JSON array data.
        if (json && Array.isArray(json)) {
         // Map each *item* in the JSON array to transform it into an object with defined properties.
          const transformedData = json.map((item) => ({ 
            // Define the properties of the transformed object
            id: String(item.CUSTOMERNUMBER || 'N/A'), // Must be unique, i.e. primary key
            title: `${String(item.LASTNAME || 'No Last Name')}, ${String(item.FIRSTNAME || 'No First Name')} (${String(item.STATUS || 'No Status')})`,
           // Define the details of the transformed object
            details: {
              LASTNAME: String(item.LASTNAME || 'No Last Name'),
			  STATUS: String(item.STATUS || 'N/A'),
			  CLOUD: String(item.CLOUD || 'N/A'),
              CUSTOMERNUMBER: String(item.CUSTOMERNUMBER || 'N/A'),
              STREET: String(item.ADDRESS || 'N/A'),
              CITY: String(item.CITY || 'N/A'),
              ST: String(item.ST || 'N/A'),
              ZIP: String(item.ZIP || 'N/A'),
              PHONE: String(item.PHONE || 'N/A'),
              EMAIL: String(item.EMAIL || 'N/A'),
            },
          }));

          setData(transformedData); // Set the transformed data to the state variable "data" 
          setFilteredData(transformedData);
          setLoading(false);
        } else {
          throw new Error('Unexpected API response format. Expected a JSON array.');
        }
      })
      .catch((err) => {
//        console.error('Error occurred during fetch:', err);
        setError(err.message);
        setLoading(false);
      });
  }, []);

  /**************************************************************************
   * Toggles the expanded state of the item
   * @param {string} id - The ID of the item to toggle
   **************************************************************************/ 
  const toggleExpand = (id) => { // Toggle the expanded state of the item with the specified ID
    setExpanded((prev) => {      // Set the expanded state of the item with the specified ID
      if (prev[id]) {            // If the item is already expanded, collapse it
        return { [id]: false };  // Return the collapsed state
      } 
      return { [id]: true };     // Otherwise, expand the item
    });
  };

  /**************************************************************************
   * Initiates a phone call to the specified number using the device's dialer
   * @param {string} phoneNumber - The phone number to dial
   **************************************************************************/    
  const handlePhonePress = async (phoneNumber) => {
    try {
      const cleanNumber = phoneNumber.replace(/[^\d+]/g, '');
      const phoneUrl = `tel:${cleanNumber}`;
      
      // Remove the canOpen check and directly try to open
      await Linking.openURL(phoneUrl); // Open the phone URL
    } catch (error) {
//      console.error('Phone error:', error);
      Alert.alert(
        'Error',
        'Unable to make phone call.',
        [{ text: 'OK' }]
      );
    }
  };

  /**************************************************************************
   * Initiates an eMail to the specified address using the device's email client
   * @param {string} email - The email address to send to
   **************************************************************************/   
  const handleEmailPress = async (email) => {
    try {
      const emailUrl = `mailto:${email}`;
      
      // Remove the canOpen check and directly try to open
      await Linking.openURL(emailUrl);
    } catch (error) {
//      console.error('Email error:', error);
      Alert.alert(
        'Error',
        'Unable to open email client.',
        [{ text: 'OK' }]
      );
    }
  };
/**************************************************************************
 * Applies the filters to the data. Used by button press and picker change
 * to filter the data based on the last name and status filters.
 * Filters are applied in a case-insensitive manner.
 * If the last name filter is empty and the status filter is set to "-",
 * the data is not filtered.
 * If the last name filter is set, only items with a last name containing
 * the filter text are included.
 * If the status filter is set to a value other than "-", only items with
 * a matching status are included.
 * If both filters are set, only items matching both filters are included.
 * If no items match the filters, the filtered data is set to an empty array.
 * **************************************************************************/
  const applyFilters = () => {
    Keyboard.dismiss();
    if (!data) return;

    if (!lastNameFilter.trim() && statusFilter === "-") {
      setFilteredData(data);
      return;
    }

    let filtered = data;

    if (lastNameFilter.trim()) {
      filtered = filtered.filter((item) =>
        item.details.LASTNAME.toLowerCase().includes(lastNameFilter.toLowerCase())
      );
    }

    if (statusFilter !== "-") {
      filtered = filtered.filter((item) => item.details.STATUS === statusFilter);
    }

    setFilteredData(filtered);
  };

  /***************************************************************************
   * Renders the loading indicator, error message, or customer list
   ***************************************************************************/
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }
/**************************************************************************
 * Formats the amount as currency using the US locale
 * @param {string} amount - The amount to format as currency
 * @returns {string} The amount formatted as currency
 * **************************************************************************/
  const formatCurrency = (amount) => {
    if (!amount || isNaN(parseFloat(amount))) return 'N/A';  
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(parseFloat(amount));
  };

  /*******************************************************************************
   * Renders the main application view with the customer list and filter controls 
   *******************************************************************************/
  return (
    <View style={styles.container}> 
      <ScrollView> 
        {/* Instruction Panel */}
        <View style={styles.topPanel}>  
          <Text style={styles.topPanelText}>
            Touch a name to show or hide details. Filter results at the bottom.
          </Text>
        </View>

        {/* Customer List */}
        {filteredData && filteredData.length > 0 ? (
          filteredData.map((item) => (
            <View key={item.id} style={styles.item}>
              <TouchableOpacity onPress={() => toggleExpand(item.id)}>
                <Text style={styles.title}>{String(item.title)}</Text>
              </TouchableOpacity>

        {/* Expanded Details */}
        {expanded[item.id] && (
        <View style={styles.detailsContainer}>
          <Text style={styles.details}>Customer: {String(item.details.CUSTOMERNUMBER ?? 'N/A')}</Text>
          <Text style={styles.details}>Cloud: {String(item.details.CLOUD ?? 'N/A')}</Text>
          <Text style={styles.details}>City: {String(item.details.CITY ?? 'N/A')}</Text>
          <Text style={styles.details}>ST: {String(item.details.ST ?? 'N/A')}</Text>
          <Text style={styles.details}>ZIP: {String(item.details.ZIP ?? 'N/A')}</Text>
          <Text style={styles.details}>PHONE: {String(item.details.PHONE ?? 'N/A')}</Text>
          <Text style={styles.details}>Renewal: {String(item.details.RNW_DATE ?? 'N/A')}</Text> 
          
          {/* Touchable Phone number*/}
          {item.details.PHONE && item.details.PHONE !== "N/A" && (
            <TouchableOpacity onPress={() => handlePhonePress(item.details.PHONE)}> 
              <Text style={styles.phoneNumber}>{item.details.PHONE}</Text>
            </TouchableOpacity>
          )}

          {/* Touchable eMail address */
           item.details.EMAIL && item.details.EMAIL !== "N/A" && (
            <TouchableOpacity onPress={() => handleEmailPress(item.details.EMAIL)}>
              <Text style={styles.eMail}>{item.details.EMAIL}</Text>
            </TouchableOpacity>
          )}
    
        </View>
      )}
    </View>
  ))
        ) : (
          <View style={styles.noResultsContainer}>
            <Text style={styles.noResultsText}>No results found.</Text>
          </View>
        )}
      </ScrollView>

      {/* Filter Controls */}
    <View style={styles.bottomPanel}>
      <View style={styles.nameFilterRow}>
        <TextInput
          style={styles.nameFilterInput}
          placeholder="Enter Last Name"
          value={lastNameFilter}
          onChangeText={(text) => setLastNameFilter(text)}
        />
        <TouchableOpacity style={styles.smallButton} onPress={applyFilters}> 
          <Text style={styles.smallButtonText}>Ok</Text>
        </TouchableOpacity>
      </View>
        <View style={styles.pickerContainer}>
          <Picker
          selectedValue={statusFilter}
          style={styles.picker}
          itemStyle={styles.pickerItem}
          onValueChange={(value) => {
            setStatusFilter(value);
            
            Keyboard.dismiss(); 
            if (!data) return;  

            if (!lastNameFilter.trim() && value === "-") {
              setFilteredData(data);  
              return;
            }

            let filtered = data; 
			/*  Make filtering case insensitive */			
            if (lastNameFilter.trim()) { 
              filtered = filtered.filter((item) =>
                item.details.LASTNAME.toLowerCase().includes(lastNameFilter.toLowerCase())
              );
            }

            if (value !== "-") {
              if (value === "C") {
                filtered = filtered.filter((item) =>  
                  (item.details.CLOUD === "Y" || item.details.CLOUD === "y") && 
                  item.details.STATUS === "A"
                );
              } else {
                filtered = filtered.filter((item) => item.details.STATUS === value);
              }
            }

            setFilteredData(filtered);
          }}
          /* Picker Items */
        >
          <Picker.Item label="All Accounts" value="-" /> 
          <Picker.Item label="Active users" value="A" /> 
          <Picker.Item label="Inactive users" value="I" />
          <Picker.Item label="Prospect users" value="P" />
          <Picker.Item label="Read Only users" value="R" />
          <Picker.Item label="Cloud - Active Users" value="C" />
        </Picker>
      </View>
    </View>
  </View>    
  );
};

/*******************************************************************
 * StyleSheet contains all the styles for the various visible 
 * components. For example, it determines how tall, wide, color,
 * and other features of a button or textInput.
 ********************************************************************/
const styles = StyleSheet.create({
    container: {
      flex: 1,
      padding: 5,
      backgroundColor: '#008B8B', // Colors can be hex or a valid named value. 
    },
    loadingContainer: {
      flex: 1, // Flex is a property of CSS that allows you to specify how a layout should grow or shrink to fit the space available.
      justifyContent: 'center', // The CSS justify-content property defines how the browser distributes space between and around content items along the main-axis of a flex container, and the inline axis of a grid container.
      alignItems: 'center', // The CSS align-items property sets the align-self value on all direct children as a group. The align-self property sets the alignment of an item within its containing block.
    },
    errorContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    errorText: {
      color: 'red',
      fontSize: 16,
      textAlign: 'center',
    },
    topPanel: {
      padding: 1,
      backgroundColor: 'yellow',
      borderRadius: 5,
      borderColor: 'black',
      borderWidth: 2,
      marginBottom: 5,
      marginTop: 0,
      height: 60,
    },
    topPanelText: {
      fontSize: 16,
      color: 'black',
      textAlign: 'left',
    },
    item: {
      marginBottom:3,
      backgroundColor: '#e0ffff',  
      padding: 3, // Add padding to the item container 
      borderRadius: 5,
      shadowColor: '#000', 
      shadowOpacity: 0.1,  
      shadowRadius: 3,
      elevation: 2,
      borderColor: 'black',
      borderWidth: 1,
    },
    title: {
      fontSize: 15,
      fontWeight: 'bold',
      borderColor: 'black',
    },
    details: {
      fontSize: 14,
      color: 'black',
      marginTop: -3,
    },
    phoneNumber: {
      fontSize: 16,
      textDecorationLine: 'underline',
      textDecorationColor: '#191970',
      marginTop: 5,
    },
    eMail: {
      fontSize: 16,
      textDecorationLine: 'underline', // Underline the text
      textDecorationColor: '#191970',  // Dark blue underline
      marginTop: 5,
      marginBottom: 5,
    },
    bottomPanel: {
      padding: 7,
      backgroundColor: '#191970', // Midnight Blue background color 
      borderRadius: 6, // Rounded corners
      marginTop: 20,  // Add some space above the filter controls 
      borderTopColor: 'black',
      borderTopWidth: 2,
    },
    nameFilterRow: {
      flexDirection: 'row', // Row layout for the filter input and button
      alignItems: 'center',
      marginBottom: 10,
      gap: 10,
    },
    nameFilterInput: {
      flex: 1, // Flex is a property of CSS that allows you to specify how a layout should grow or shrink to fit the space available.
      fontSize: 16, // Larger font size
      backgroundColor: 'white', // White background
      paddingHorizontal: 10, // Add padding to the left and right
      height: 44, // Match the height of the text input
      borderRadius: 5, // Rounded corners
      marginBottom: 0,  // Remove this margin since we're using gap in the row
    },
    
    pickerContainer: {
      backgroundColor: '#fff', // White background
      borderWidth: 1, // Add a border
      borderColor: '#ccc', // Light gray border
      borderRadius: 5, // Rounded corners
      overflow: 'hidden', // Hide the overflow
    },
    picker: { // Picker is like a Delphi TComboBox
      width: '100%', // Full width
      height: 53, // Match the height of the text input
      marginVertical: -10, // Remove this margin since it's already in the row
      marginBottom: 0, // Remove this margin since we're using gap in the row
    },
    pickerItem: {
      fontSize: 16, // Larger font size
    },
    smallButton: {
      backgroundColor: '#00BFFF', // Dodger Blue
      paddingVertical: 5, // Reduced padding since it now only says "Ok"
      paddingHorizontal: 15, // Reduced padding since it now only says "Ok"
      borderRadius: 5, // Rounded corners
      alignItems: 'center', // Center the text
      justifyContent: 'center', // Center the text
      elevation: 2, // Android shadow
      shadowColor: '#000', // iOS shadow
      shadowOpacity: 0.1, // iOS shadow
      shadowRadius: 2, // iOS shadow
      shadowOffset: { width: 0, height: 2 }, // iOS shadow
      width: 60,  // Reduced width since it now only says "Ok"
      height: 44,  // Match the height of the text input
      marginTop: 0,  // Remove this margin since we're using gap in the row
    },
    smallButtonText: {
      color: '#fff',  // White text
      fontSize: 12, // Reduced font size since it now only says "Ok"
      fontWeight: 'bold', // Bold text
      textAlign: 'center', // Center the text
    },
    noResultsContainer: {
      alignItems: 'center', // Center the text
      marginTop: 20, // Add some space above the text
    },
    noResultsText: {
      fontSize: 16, // Larger font size
      fontWeight: 'bold', // Bold text
      color: 'gray', // Gray text
    },     
    
  });


export default App;
