/* Login screen. Uses the device's secure storage (SecureStore) for storing passwords and security questions & answers. */
import React, { useState, useEffect, useRef } from 'react';
import { 
  View, Text, TextInput, Alert, StyleSheet, 
  ImageBackground, TouchableOpacity 
} from 'react-native';
import { useRouter } from 'expo-router';  
import * as SecureStore from 'expo-secure-store'; 
import MyImg from "@/assets/images/YourGraphic.jpg";  // replace with your image.

// Variables to store Secure Keys
const PASSWORD_KEY = 'app_password';
const SECURITY_QUESTION_KEY = 'security_question';
const SECURITY_ANSWER_KEY = 'security_answer';
const ADMIN_OVERRIDE_KEY = 'admin_override'; // Admin override key

const Index = () => {
  const [storedPassword, setStoredPassword] = useState(null);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [securityQuestion, setSecurityQuestion] = useState('');
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [isSettingPassword, setIsSettingPassword] = useState(false);
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [resetAnswer, setResetAnswer] = useState('');
  const [adminCode, setAdminCode] = useState('');
  const [securityAttempts, setSecurityAttempts] = useState(0);
  const [showAdminOverride, setShowAdminOverride] = useState(false);

  const router = useRouter();
  const passwordRef = useRef(null);
  const securityAnswerRef = useRef(null);

  useEffect(() => {
    const initializeApp = async () => {
      const savedPassword = await SecureStore.getItemAsync(PASSWORD_KEY);
      const savedQuestion = await SecureStore.getItemAsync(SECURITY_QUESTION_KEY);
      const savedAdminOverride = await SecureStore.getItemAsync(ADMIN_OVERRIDE_KEY);

      setStoredPassword(savedPassword);
      setSecurityQuestion(savedQuestion || '');
      setIsSettingPassword(!savedPassword);

      // ✅ Set admin override if it doesn’t exist. This is hard-coded. A better way would be to create an off-site generated override
			// but that can come later.
      if (!savedAdminOverride) {
        await SecureStore.setItemAsync(ADMIN_OVERRIDE_KEY, 'YourAdminOverrideValuable!'); // Override code
//        console.log('Admin override code set!');
      }
    };

    initializeApp();
  }, []);

  useEffect(() => {
    if (isSettingPassword && passwordRef.current) {
      passwordRef.current.focus(); 
    }
  }, [isSettingPassword]);

  const handleLogin = async () => {
    if (!storedPassword) {
      Alert.alert('Error', 'No password set. Please create a new one.');
      return;
    }
    if (password.trim() === storedPassword) {
      router.push('/explore');  
    } else {
      Alert.alert('Error', 'Incorrect password');
    }
  };

  const handleSetPassword = async () => {
		const trimmedPassword = password.trim();
		const trimmedConfirmPassword = confirmPassword.trim();
		const trimmedSecurityAnswer = securityAnswer.trim().toLowerCase();

		if (trimmedPassword.length < 4) {
			Alert.alert('Error', 'Password must be at least 4 characters long.');
			return;
		}
		if (trimmedPassword !== trimmedConfirmPassword) {
			Alert.alert('Error', 'Passwords do not match.');
			return;
		}
		if (!securityQuestion.trim() || !trimmedSecurityAnswer) {
			Alert.alert('Error', 'Please provide a security question and answer.');
			return;
		}
		await SecureStore.setItemAsync(PASSWORD_KEY, trimmedPassword);
		await SecureStore.setItemAsync(SECURITY_QUESTION_KEY, securityQuestion);
		await SecureStore.setItemAsync(SECURITY_ANSWER_KEY, trimmedSecurityAnswer);

		setStoredPassword(trimmedPassword);
		setIsSettingPassword(false);
		setIsResettingPassword(false);
		setSecurityAttempts(0);
		Alert.alert('Success', 'Password has been set.');
	};

  const handleResetPassword = async () => {
    const savedAnswer = await SecureStore.getItemAsync(SECURITY_ANSWER_KEY);
    if (!savedAnswer) {
      Alert.alert('Error', 'No security question is set up.');
      return;
    }
    if (resetAnswer.trim().toLowerCase() !== savedAnswer) {
      const attempts = securityAttempts + 1;
      setSecurityAttempts(attempts);

      if (attempts >= 3) {
        setShowAdminOverride(true);
        Alert.alert('Error', 'Too many failed attempts. Admin override required.');
      } else {
        Alert.alert('Error', `Incorrect security answer. ${3 - attempts} attempt(s) left.`);
        setResetAnswer('');
        securityAnswerRef.current.focus();
      }
      return;
    }
    await SecureStore.deleteItemAsync(PASSWORD_KEY);
    setStoredPassword(null);
    setIsSettingPassword(true);
    setIsResettingPassword(false);
    setSecurityAttempts(0);
    setShowAdminOverride(false);
    Alert.alert('Success', 'You can now set a new password.');
  };

  const handleAdminOverride = async () => {
    const savedAdminCode = await SecureStore.getItemAsync(ADMIN_OVERRIDE_KEY);
    if (adminCode === savedAdminCode) {
      await SecureStore.deleteItemAsync(PASSWORD_KEY);
      setStoredPassword(null);
      setIsSettingPassword(true);
      setShowAdminOverride(false);
      setSecurityAttempts(0);
      Alert.alert('Admin Override', 'You can now set a new password.');
    } else {
      Alert.alert('Error', 'Invalid admin override code.');
    }
  };

  return (
    <View style={styles.container}>
      <ImageBackground source={MyImg} style={styles.image}>
        <Text style={styles.title}>ABS Mobile Admin</Text>
        <Text style={styles.introText}>Welcome to ABS User Administration</Text>
        <Text style={styles.introText}>Unauthorized use may result in civil or criminal penalty.</Text>
        <Text style={styles.introText}>{'\n © 2025 - Agency Business Systems, Inc\n\n'}</Text>

        {isSettingPassword ? (
          <>
            <TextInput
              ref={passwordRef}
              style={styles.authInput}
              placeholder="Create Password"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
            />
            <TextInput
              style={styles.authInput}
              placeholder="Confirm Password"
              secureTextEntry
              value={confirmPassword}
              onChangeText={setConfirmPassword}
            />
            <TextInput
              style={styles.authInput}
              placeholder="Security Question"
              value={securityQuestion}
              onChangeText={setSecurityQuestion}
            />
            <TextInput
              style={styles.authInput}
              placeholder="Security Answer"
              value={securityAnswer}
              onChangeText={setSecurityAnswer}
            />
            <TouchableOpacity style={styles.submitButton} onPress={handleSetPassword}>
              <Text style={styles.submitButtonText}>Set Password</Text>
            </TouchableOpacity>
          </>
        ) : isResettingPassword ? (
          <>
            <Text style={styles.securityQuestionText}>{securityQuestion}</Text>
            <TextInput
              ref={securityAnswerRef}
              style={styles.authInput}
              placeholder="Enter Security Answer"
              value={resetAnswer}
              onChangeText={setResetAnswer}
            />
            <TouchableOpacity style={styles.submitButton} onPress={handleResetPassword}>
              <Text style={styles.submitButtonText}>Reset Password</Text>
            </TouchableOpacity>

            {showAdminOverride && (
              <>
                <TextInput
                  style={styles.authInput}
                  placeholder="Enter Admin Override Code"
                  value={adminCode}
                  onChangeText={setAdminCode}
                />
                <TouchableOpacity style={styles.submitButton} onPress={handleAdminOverride}>
                  <Text style={styles.submitButtonText}>Admin Reset</Text>
                </TouchableOpacity>
              </>
            )}
          </>
        ) : (
          <>
            <TextInput
              style={styles.authInput}
              placeholder="Enter Password"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity style={styles.submitButton} onPress={handleLogin}>
              <Text style={styles.submitButtonText}>Login</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.forgotButton} onPress={() => setIsResettingPassword(true)}>
              <Text style={styles.forgotButtonText}>Forgot Password?</Text>
            </TouchableOpacity>
          </>
        )}
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    alignItems: 'center', 
    justifyContent: 'center', 
  },
  image: { 
    width: '100%', 
    height: '100%', 
    flex: 1, 
    resizeMode: 'cover', 
    justifyContent: 'center', 
  },
  title: { 
    color: 'white', 
    fontSize: 42, 
    fontWeight: 'bold', 
    textAlign: 'center', 
    backgroundColor: 'rgba(0, 0, 0, 0.5)', 
  },
  introText: { 
    color: 'white', 
    fontSize: 14, 
    textAlign: 'center', 
    fontStyle: 'italic',
 },
  authInput: { 
    width: '80%', 
    padding: 10, 
    alignItems: 'center',
    marginVertical: 10, 
    borderColor: '#ccc', 
    borderWidth: 1, 
    borderRadius: 5, 
    backgroundColor: 'white', 
    marginHorizontal: 'auto',
  },
  submitButton: { 
    backgroundColor: '#4CAF50', 
    padding: 12, 
    borderRadius: 5, 
    alignItems: 'center', 
    width: 190,
    justifyContent: 'center',
    elevation: 2,
    marginHorizontal: 'auto',   
  },
  submitButtonText: { color: 'white', fontSize: 18, fontWeight: 'bold' },
  forgotButton: { 
    marginTop: 10,
    padding: 12, 
    borderRadius: 5, 
    alignItems: 'center',
    backgroundColor: 'darkblue',
    marginHorizontal: 'auto', 
  },
  forgotButtonText: { 
    color: 'yellow', 
    fontSize: 16 ,
  },
  securityQuestionText: { 
    color: 'white', 
    textAlign: 'center', 
    fontSize: 16, 
    marginBottom: 10 ,
  },

});

export default Index;
